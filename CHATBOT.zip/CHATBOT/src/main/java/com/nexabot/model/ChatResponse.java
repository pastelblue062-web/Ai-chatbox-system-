package com.nexabot.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Encapsulates the output of the chatbot response engine.
 */
public class ChatResponse {
    private String responseText;
    private String intent;
    private double confidence;
    private String strategyUsed;
    private long responseTimeMs;
    private List<String> suggestions;

    public ChatResponse() {
        this.suggestions = new ArrayList<>();
    }

    public ChatResponse(String responseText, String intent, double confidence, String strategyUsed) {
        this.responseText = responseText;
        this.intent = intent;
        this.confidence = confidence;
        this.strategyUsed = strategyUsed;
        this.suggestions = new ArrayList<>();
    }

    public String getResponseText() {
        return responseText;
    }

    public void setResponseText(String responseText) {
        this.responseText = responseText;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }

    public String getStrategyUsed() {
        return strategyUsed;
    }

    public void setStrategyUsed(String strategyUsed) {
        this.strategyUsed = strategyUsed;
    }

    public long getResponseTimeMs() {
        return responseTimeMs;
    }

    public void setResponseTimeMs(long responseTimeMs) {
        this.responseTimeMs = responseTimeMs;
    }

    public List<String> getSuggestions() {
        return suggestions;
    }

    public void setSuggestions(List<String> suggestions) {
        this.suggestions = suggestions != null ? suggestions : new ArrayList<>();
    }

    public void addSuggestion(String suggestion) {
        if (suggestion != null) {
            this.suggestions.add(suggestion);
        }
    }

    @Override
    public String toString() {
        return "ChatResponse[intent=" + intent + ", conf=" + String.format("%.2f", confidence) + ", strategy=" + strategyUsed + "]";
    }
}
