# 🤖 NexaBot - AI Chatbot System

[![Java](https://img.shields.io/badge/Java-17%2B%20%7C%2021%20%7C%2025-ED8B00?logo=openjdk&logoColor=white)](https://www.oracle.com/java/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0%2B-4479A1?logo=mysql&logoColor=white)](https://www.mysql.com/)
[![Swing](https://img.shields.io/badge/GUI-Java%20Swing-orange)](https://docs.oracle.com/javase/tutorial/uiswing/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

> **Complete Java GUI + MySQL + NLP Desktop Academic Project Specification**  
> Developed for second-year computer science evaluation, designed to achieve full marks across all rubric criteria.

---

## 👥 Project Team
1. **Arifa Firdous**
2. **Muskan Pandey**
3. **Rajvardhan Singh Parmar**

---

## 📖 Project Overview

**NexaBot** is an intelligent, desktop-based conversational AI assistant designed to provide fast, reliable answers to questions concerning **Java Programming**, **Object-Oriented Design (OOP)**, **Database Systems (JDBC & MySQL)**, and **Data Structures**.

Built using **Java Swing** and backed by **MySQL**, NexaBot demonstrates how fundamental software engineering principles—Object-Oriented Programming, Collections, Generics, Concurrency, and Natural Language Processing—converge into a clean, modern software application without reliance on external paid cloud AI APIs.

---

## ✨ Key Features

- **Modern Desktop GUI**: Sleek dark/slate card interface with styled speech bubbles, avatar badges, message timestamps, confidence pills, and smooth scrolling.
- **Rule-Based NLP Preprocessing**:
  1. Case normalization and trimming
  2. Punctuation stripping via regular expressions
  3. Whitespace tokenization
  4. Stop-word filtering (`Set<String>`)
  5. Keyword extraction and Jaccard similarity scoring
- **Extensible Intent System**: Extensible architecture mapping user queries to predefined intents (`JAVA`, `OOP`, `INHERITANCE`, `POLYMORPHISM`, `JDBC`, `MULTITHREADING`, `COLLECTIONS`, `HELP`, etc.).
- **Response Confidence Engine**: Computes an interpretable confidence score ($0.0$ to $1.0$) using weighted token overlap; triggers graceful fallback recommendations when confidence is below threshold.
- **Session & User Authentication**:
  - Secure registration and login.
  - Role-based permissions (`RegularUser` vs `Admin`).
  - Salted SHA-256 password hashing.
- **Feedback & Quality Rating System**: Interactive 👍 Helpful and 👎 Not Helpful rating buttons with instant MySQL persistence.
- **Conversation History Viewer**: Dedicated split-pane browser displaying past user chat sessions and transcripts.
- **Live Analytics Dashboard**: Aggregates total users, chat sessions, message volume, satisfaction percentage, and dynamic horizontal intent frequency bars.
- **Admin Knowledge Base Portal**: Administrators can view, filter, add, and delete Q&A pairs directly into MySQL at runtime without restarting the application.
- **High-Resilience Offline Mode**: If MySQL is offline or not configured yet, NexaBot seamlessly operates in an in-memory mode, ensuring smooth evaluation and grading demonstrations under any environment.

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    User([User]) -->|Inputs Query| GUI[Java Swing Desktop GUI]
    GUI -->|Asynchronous Task| ChatService[Chatbot Service Layer]
    
    subgraph Chatbot_Core [NLP Chatbot Engine]
        ChatService --> TextProc[Text Processor]
        TextProc -->|Clean Tokens| IntentDet[Intent Detector]
        IntentDet -->|Similarity & Confidence| RespEng[Response Engine]
        RespEng -->|Polymorphic Dispatch| Strategy{Response Strategy}
        Strategy -->|Rule Based| S1[RuleBasedResponseStrategy]
        Strategy -->|Keyword Match| S2[KeywordResponseStrategy]
        Strategy -->|Low Confidence| S3[FallbackResponseStrategy]
        RespEng --> KB[(Knowledge Base Layer)]
    end
    
    subgraph Persistence [Data Access Layer]
        ChatService --> DAOLayer[DAO Layer - Repository Pattern]
        DAOLayer --> UserDAO[UserDAO]
        DAOLayer --> MsgDAO[MessageDAO]
        DAOLayer --> ConvDAO[ConversationDAO]
        DAOLayer --> FeedDAO[FeedbackDAO]
        DAOLayer --> KBDAO[KnowledgeBaseDAO]
        DAOLayer --> JDBC[DatabaseConnection - JDBC]
        JDBC --> MySQL[(MySQL Server: nexabot_db)]
    end
    
    subgraph Concurrency [Multithreading & Monitoring]
        ChatService --> ThreadPool[ThreadPoolManager - ExecutorService]
        ChatService --> Metrics[SharedMetricsMonitor - Synchronized]
    end
    
    Strategy -->|Formatted ChatResponse| GUI
```

---

## 🧩 Academic Rubric Implementation Details

| Rubric Requirement | Marks | Project Implementation |
|---|---|---|
| **Polymorphism** | Included | `ResponseStrategy` interface with `KeywordResponseStrategy`, `RuleBasedResponseStrategy`, and `FallbackResponseStrategy`. Dynamic strategy dispatch in `ResponseEngine`. |
| **Inheritance** | Included | Abstract class `User` extended by concrete subclasses `RegularUser` and `Admin` with distinct privilege overrides. |
| **Exception Handling** | Included | Custom hierarchy rooted at `NexaBotException` (`DatabaseException`, `AuthenticationException`, `InvalidInputException`, `ChatbotProcessingException`). Zero empty catch blocks. |
| **Interfaces** | Included | `Repository<T, ID>`, `ResponseStrategy`, `ChatbotService`, `AuthenticationService`. |
| **Collections** | 6 | `List<Message>`, `Map<String, Intent>`, `Set<String>` (stop words and keywords), `Map<String, Integer>` (analytics frequency maps). |
| **Generics** | 6 | Generic `Repository<T, ID>` interface implemented by `UserDAO`, `MessageDAO`, `ConversationDAO`, `FeedbackDAO`, `KnowledgeBaseDAO`. |
| **Multithreading** | 4 | Background workers (`ExecutorService`, `ThreadPoolManager`, `SwingWorker`) run NLP parsing and DB operations off the Event Dispatch Thread (EDT). |
| **Synchronization** | 4 | Thread-safe `SharedMetricsMonitor` coordinates concurrent counters, latency timers, and intent hit maps using `synchronized` blocks and `AtomicInteger`. |
| **Database Operation Classes** | 7 | Comprehensive DAO layer: `UserDAO`, `MessageDAO`, `ConversationDAO`, `FeedbackDAO`, `KnowledgeBaseDAO`, `AnalyticsDAO`. |
| **JDBC Implementation** | 3 | Dedicated `DatabaseConnection` singleton using `PreparedStatement`, `Connection`, `ResultSet`, and `SQLException` handling. |

---

## 🗄️ Database Design

The database schema is defined in [`database/schema.sql`](database/schema.sql):

- **`users`**: User ID (PK), Name, Email (Unique), Salted SHA-256 Password, Role (`USER`/`ADMIN`), Timestamp.
- **`conversations`**: Conversation ID (PK), User ID (FK), Title, Started At.
- **`messages`**: Message ID (PK), Conversation ID (FK), User ID (FK), User Message, Bot Response, Intent, Confidence, Created At.
- **`feedback`**: Feedback ID (PK), Message ID (FK), User ID (FK), Rating ($1$ or $0$), Comment, Created At.
- **`knowledge_base`**: Knowledge ID (PK), Intent, Sample Question, Keywords, Response Text, Created At.

Pre-seeded queries and sample data are provided in [`database/sample_data.sql`](database/sample_data.sql).

---

## 🚀 Quick Start Guide

### Prerequisites
- **Java Development Kit (JDK 17 or higher)** (Java 17, 21, or 25).
- **MySQL Server 8.0+** (Optional: application will automatically run in In-Memory Demo Mode if MySQL is offline).

### 1. Database Setup (Optional for Full MySQL Mode)
Open MySQL terminal or Workbench and execute:
```sql
SOURCE database/schema.sql;
SOURCE database/sample_data.sql;
```

### 2. Configure Database Credentials
Edit `src/main/resources/config.properties` or create `config.properties` in the project root:
```properties
db.host=localhost
db.port=3306
db.name=nexabot_db
db.user=root
db.password=your_mysql_password_here
db.demo_fallback=true
```

### 3. Build & Run

#### Option A: Using Windows Batch Scripts (Recommended)
Double-click or run:
```cmd
build.bat
run.bat
```

#### Option B: Using Command Line
Compile:
```cmd
javac -encoding UTF-8 -cp ".;lib/mysql-connector-j-8.3.0.jar;src/main/resources" -d bin src/main/java/com/nexabot/model/*.java src/main/java/com/nexabot/exception/*.java src/main/java/com/nexabot/util/*.java src/main/java/com/nexabot/database/*.java src/main/java/com/nexabot/dao/*.java src/main/java/com/nexabot/chatbot/*.java src/main/java/com/nexabot/strategy/*.java src/main/java/com/nexabot/concurrent/*.java src/main/java/com/nexabot/service/*.java src/main/java/com/nexabot/gui/*.java src/main/java/com/nexabot/*.java
```
Run:
```cmd
java -cp ".;bin;lib/mysql-connector-j-8.3.0.jar;src/main/resources" com.nexabot.Main
```

#### Option C: In Any Java IDE (IntelliJ IDEA / Eclipse / NetBeans)
1. Open the project folder `d:\CHATBOT` in your IDE.
2. Add `lib/mysql-connector-j-8.3.0.jar` as a Project Library (or import as Maven project via `pom.xml`).
3. Run the main class: `com.nexabot.Main`.

---

## 🔑 Default Demonstration Accounts

For ease of academic grading and testing, pre-configured accounts are provided with single-click autofill buttons on the login screen:

| Role | Email | Password | Privileges |
|---|---|---|---|
| **System Administrator** | `admin@nexabot.ai` | `Admin@123` | Full Access: Chat, History, Analytics, Manage Knowledge Base |
| **Student / User** | `arifa@nexabot.ai` | `User@123` | Standard Access: Chat, Feedback, Personal History, Analytics |
| **Student / User** | `muskan@nexabot.ai` | `User@123` | Standard Access |
| **Student / User** | `rajvardhan@nexabot.ai` | `User@123` | Standard Access |

*Note: You can also register a new account anytime on the Registration screen.*

---

## 🧪 Automated Testing

NexaBot includes an automated test verification suite [`ChatbotTestSuite.java`](src/test/java/com/nexabot/ChatbotTestSuite.java).

Run tests with:
```cmd
test.bat
```
Output:
```
=================================================
  Running NexaBot Automated Verification Suite   
=================================================
--- Testing NLP TextProcessor ---
  [PASS] Text cleaning removes punctuation & converts lowercase
  [PASS] Tokenization produces correct word count
  [PASS] Stop-words filtered while 'java' preserved
--- Testing Security & Password Hashing ---
  [PASS] Hash contains salt separator ':'
  [PASS] Verification succeeds with correct password
  [PASS] Verification fails with incorrect password
--- Testing Validation Rules ---
  [PASS] Valid email accepted
  [PASS] Malformed email rejected
  [PASS] Empty chat message rejected
--- Testing OOP Hierarchy & Polymorphism ---
  [PASS] RegularUser role equals 'USER'
  [PASS] RegularUser cannot manage KB
  [PASS] Admin role equals 'ADMIN'
  [PASS] Admin can manage KB
--- Testing Response Engine & Knowledge Base ---
  [PASS] Greeting matches GREETING intent
  [PASS] Greeting has high confidence
  [PASS] Java query matches JAVA intent
  [PASS] Java query has confidence > 0.5
  [PASS] OOP query matches OOP intent
  [PASS] Unrecognized input triggers FallbackResponseStrategy
--- Testing Thread Safety & Synchronization ---
  [PASS] Total messages counter increments correctly
  [PASS] Intent frequency snapshot contains JAVA
-------------------------------------------------
Test Results: 21 / 21 Tests Passed.
>>> ALL TESTS PASSED SUCCESSFULLY! <<<
```

---

## 📂 Project Directory Structure

```
d:\CHATBOT\
├── src/
│   ├── main/
│   │   ├── java/com/nexabot/
│   │   │   ├── Main.java                        # Application Launcher
│   │   │   ├── model/                          # Encapsulated Data Models
│   │   │   │   ├── User.java                   # Abstract Base Class (Inheritance)
│   │   │   │   ├── Admin.java                  # Specialized Admin User
│   │   │   │   ├── RegularUser.java            # Standard Student User
│   │   │   │   ├── Message.java                # Message Exchange Model
│   │   │   │   ├── Conversation.java           # Chat Session Model
│   │   │   │   ├── Feedback.java               # Rating Feedback Model
│   │   │   │   ├── Intent.java                 # Chatbot Intent Representation
│   │   │   │   ├── KnowledgeEntry.java         # Database Q&A Row Model
│   │   │   │   ├── ChatResponse.java           # Engine Output Encapsulation
│   │   │   │   └── AnalyticsData.java          # Dashboard Metrics Model
│   │   │   ├── dao/                            # Database Access Object Layer
│   │   │   │   ├── Repository.java             # Generic Repository<T, ID> Interface
│   │   │   │   ├── UserDAO.java                # User JDBC Operations
│   │   │   │   ├── ConversationDAO.java        # Conversation JDBC Operations
│   │   │   │   ├── MessageDAO.java             # Message JDBC Operations
│   │   │   │   ├── FeedbackDAO.java            # Feedback JDBC Operations
│   │   │   │   ├── KnowledgeBaseDAO.java       # Knowledge Base JDBC Operations
│   │   │   │   └── AnalyticsDAO.java           # SQL Aggregations & Statistics
│   │   │   ├── database/
│   │   │   │   └── DatabaseConnection.java     # Singleton JDBC Connection Manager
│   │   │   ├── chatbot/                        # NLP Engine Core
│   │   │   │   ├── TextProcessor.java          # Tokenizer & Stop-Word Filter
│   │   │   │   ├── IntentDetector.java         # Keyword & Similarity Matcher
│   │   │   │   ├── KnowledgeBase.java          # Synchronized Intent Store
│   │   │   │   ├── ResponseEngine.java         # Orchestration & Strategy Selector
│   │   │   │   └── ChatbotService.java         # Chatbot Service Interface
│   │   │   ├── strategy/                       # Strategy Pattern (Polymorphism)
│   │   │   │   ├── ResponseStrategy.java       # Strategy Interface
│   │   │   │   ├── KeywordResponseStrategy.java# Domain Intent Response Strategy
│   │   │   │   ├── RuleBasedResponseStrategy.java# Conversational Heuristic Strategy
│   │   │   │   └── FallbackResponseStrategy.java# Intelligent Fallback Strategy
│   │   │   ├── service/                        # Business Logic Layer
│   │   │   │   ├── AuthenticationService.java  # Auth Interface
│   │   │   │   ├── AuthenticationServiceImpl.java# Auth Implementation & Session
│   │   │   │   ├── ChatbotServiceImpl.java     # Core Chat Service Implementation
│   │   │   │   └── AnalyticsService.java       # System Analytics Aggregator
│   │   │   ├── concurrent/                     # Multithreading & Synchronization
│   │   │   │   ├── ThreadPoolManager.java      # ExecutorService Background Worker
│   │   │   │   └── SharedMetricsMonitor.java   # Thread-Safe Synchronized Monitor
│   │   │   ├── exception/                      # Custom Exceptions Hierarchy
│   │   │   │   ├── NexaBotException.java       # Checked Base Exception
│   │   │   │   ├── DatabaseException.java      # SQL & Connection Failures
│   │   │   │   ├── AuthenticationException.java# Credential Validation Failures
│   │   │   │   ├── InvalidInputException.java  # Input Boundary Violations
│   │   │   │   └── ChatbotProcessingException.java# NLP Processing Failures
│   │   │   ├── util/                           # Utilities & Theming
│   │   │   │   ├── UITheme.java                # Modern Swing Palette & Borders
│   │   │   │   ├── PasswordUtil.java           # Salted SHA-256 Password Hash
│   │   │   │   ├── ValidationUtil.java         # Input Validation Helpers
│   │   │   │   └── ConfigLoader.java           # Safe External Config Loader
│   │   │   └── gui/                            # Modern Java Swing Presentation
│   │   │       ├── LoginFrame.java             # Authentication Screen
│   │   │       ├── RegisterFrame.java          # User Registration Screen
│   │   │       ├── ChatFrame.java              # Primary Interactive Chat Window
│   │   │       ├── HistoryFrame.java           # Conversation History Split-Pane
│   │   │       ├── AnalyticsFrame.java         # KPI & Visual Distribution Dashboard
│   │   │       └── AdminKnowledgeFrame.java    # Admin Knowledge Management Portal
│   │   └── resources/
│   │       └── config.properties               # Database Configuration
│   └── test/
│       └── java/com/nexabot/
│           └── ChatbotTestSuite.java           # Verification Test Suite (21 Tests)
├── database/
│   ├── schema.sql                              # DDL Schema Script
│   └── sample_data.sql                         # Seed Data Script
├── docs/
│   ├── architecture.md                         # Architecture Specifications
│   ├── database-design.md                      # Database & ER Specifications
│   ├── testing-guide.md                        # Verification & Test Matrix
│   └── presentation.md                         # 15-Slide Defense Presentation
├── lib/
│   └── mysql-connector-j-8.3.0.jar             # MySQL Official JDBC Driver
├── build.bat                                   # One-Click Build Script
├── run.bat                                     # One-Click Run Script
├── test.bat                                    # One-Click Test Script
├── pom.xml                                     # Maven Build Descriptor
├── .gitignore                                  # Git Ignore Configuration
├── LICENSE                                     # MIT License
└── README.md                                   # Project Documentation
```

---

## 🔮 Future Enhancements
- **Voice Recognition (STT / TTS)**: Integration of speech synthesis and voice input for hands-free interactions.
- **Local Machine Learning**: Offline integration with ONNX Runtime or local language models for deep natural language inference.
- **Multi-Language Support**: Real-time query translation for international languages.
- **Export Transcripts**: Export conversation histories to PDF or Markdown summaries.

---

## 📄 License
This project is released under the **MIT License**. See [`LICENSE`](LICENSE) for full details.
