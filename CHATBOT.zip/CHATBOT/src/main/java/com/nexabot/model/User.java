package com.nexabot.model;

import java.sql.Timestamp;

/**
 * Abstract base class representing a User in the NexaBot system.
 * Demonstrates:
 *  - Encapsulation: private member variables with public accessors and mutators.
 *  - Abstraction: abstract methods defining role-based behaviors.
 */
public abstract class User {
    private int userId;
    private String name;
    private String email;
    private String password; // Salted SHA-256 hash
    private Timestamp createdAt;

    public User() {
    }

    public User(int userId, String name, String email, String password, Timestamp createdAt) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.password = password;
        this.createdAt = createdAt;
    }

    public User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    // Abstract methods demonstrating polymorphism in subclasses
    public abstract String getRole();
    public abstract boolean canManageKnowledgeBase();
    public abstract boolean canViewAllAnalytics();

    // Getters and Setters (Encapsulation)
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null) {
            this.name = name.trim();
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email != null) {
            this.email = email.trim().toLowerCase();
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "User[id=" + userId + ", name='" + name + "', email='" + email + "', role='" + getRole() + "']";
    }
}
