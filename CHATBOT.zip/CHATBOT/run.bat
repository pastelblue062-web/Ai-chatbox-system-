@echo off
echo ===================================================
echo   Launching NexaBot - AI Chatbot System
echo ===================================================

if not exist bin (
    echo bin directory not found. Running build.bat first...
    call build.bat
)

java -cp ".;bin;lib\mysql-connector-j-8.3.0.jar;src\main\resources" com.nexabot.Main
pause
