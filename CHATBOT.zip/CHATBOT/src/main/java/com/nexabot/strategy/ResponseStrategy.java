package com.nexabot.strategy;

import com.nexabot.chatbot.KnowledgeBase;
import com.nexabot.model.ChatResponse;
import java.util.Set;

/**
 * Interface defining the strategy contract for chatbot response generation.
 * Demonstrates:
 *  - Interfaces
 *  - Polymorphism: Different strategies implement this interface to generate responses.
 */
public interface ResponseStrategy {

    /**
     * Determines whether this strategy can handle the given input.
     * @param tokens Cleaned tokenized words from the user message
     * @param knowledgeBase The active knowledge base
     * @return true if this strategy is suitable, false otherwise
     */
    boolean canHandle(Set<String> tokens, KnowledgeBase knowledgeBase);

    /**
     * Generates a ChatResponse based on the processed user input.
     * @param rawInput Original user message
     * @param cleanedInput Normalized and punctuation-stripped message
     * @param tokens Set of unique keyword tokens
     * @param knowledgeBase Active knowledge base
     * @return Structured ChatResponse object
     */
    ChatResponse generateResponse(String rawInput, String cleanedInput, Set<String> tokens, KnowledgeBase knowledgeBase);

    /**
     * Name identifier for the strategy (for analytics/debugging).
     */
    String getStrategyName();
}
