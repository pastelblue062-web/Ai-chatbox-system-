package com.nexabot.exception;

/**
 * Exception thrown when user credentials are invalid or authorization fails.
 */
public class AuthenticationException extends NexaBotException {

    public AuthenticationException(String message) {
        super(message);
    }

    public AuthenticationException(String message, Throwable cause) {
        super(message, cause);
    }
}
