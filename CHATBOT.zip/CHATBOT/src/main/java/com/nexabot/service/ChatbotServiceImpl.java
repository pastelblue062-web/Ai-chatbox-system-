package com.nexabot.service;

import com.nexabot.chatbot.ChatbotService;
import com.nexabot.chatbot.KnowledgeBase;
import com.nexabot.chatbot.ResponseEngine;
import com.nexabot.concurrent.SharedMetricsMonitor;
import com.nexabot.dao.ConversationDAO;
import com.nexabot.dao.FeedbackDAO;
import com.nexabot.dao.MessageDAO;
import com.nexabot.exception.ChatbotProcessingException;
import com.nexabot.exception.DatabaseException;
import com.nexabot.exception.InvalidInputException;
import com.nexabot.model.ChatResponse;
import com.nexabot.model.Conversation;
import com.nexabot.model.Feedback;
import com.nexabot.model.Message;
import com.nexabot.util.ValidationUtil;

import java.util.List;

/**
 * Service implementation coordinating Chatbot NLP engine, Multithreaded monitoring, and DAO persistence.
 */
public class ChatbotServiceImpl implements ChatbotService {

    private final ResponseEngine responseEngine;
    private final ConversationDAO conversationDAO;
    private final MessageDAO messageDAO;
    private final FeedbackDAO feedbackDAO;
    private final SharedMetricsMonitor metricsMonitor;

    public ChatbotServiceImpl() {
        KnowledgeBase kb = new KnowledgeBase();
        this.responseEngine = new ResponseEngine(kb);
        this.conversationDAO = new ConversationDAO();
        this.messageDAO = new MessageDAO();
        this.feedbackDAO = new FeedbackDAO();
        this.metricsMonitor = SharedMetricsMonitor.getInstance();
    }

    @Override
    public Conversation startNewConversation(int userId, String title) throws DatabaseException {
        if (title == null || title.trim().isEmpty()) {
            title = "Chat Session " + (System.currentTimeMillis() % 10000);
        }
        Conversation conv = new Conversation(userId, title);
        return conversationDAO.save(conv);
    }

    @Override
    public Message processMessage(int conversationId, int userId, String userMessage)
            throws ChatbotProcessingException, DatabaseException {
        try {
            ValidationUtil.validateChatMessage(userMessage);
        } catch (InvalidInputException e) {
            throw new ChatbotProcessingException(e.getMessage(), userMessage);
        }

        long start = System.currentTimeMillis();
        // 1. Process NLP and select polymorphic strategy
        ChatResponse chatResponse = responseEngine.process(userMessage);
        long duration = System.currentTimeMillis() - start;

        // 2. Update thread-safe synchronized metrics monitor
        metricsMonitor.recordMessageExchange(chatResponse.getIntent(), duration);

        // 3. Persist to MySQL via MessageDAO
        Message message = new Message(
                conversationId,
                userId,
                userMessage.trim(),
                chatResponse.getResponseText(),
                chatResponse.getIntent(),
                chatResponse.getConfidence()
        );

        return messageDAO.save(message);
    }

    @Override
    public Feedback submitFeedback(int messageId, int userId, int rating, String comment) throws DatabaseException {
        try {
            ValidationUtil.validateFeedbackRating(rating);
        } catch (InvalidInputException e) {
            throw new DatabaseException("Invalid feedback rating parameter: " + e.getMessage());
        }

        Feedback feedback = new Feedback(messageId, userId, rating, comment);
        return feedbackDAO.save(feedback);
    }

    @Override
    public List<Message> getConversationMessages(int conversationId) throws DatabaseException {
        return messageDAO.findByConversationId(conversationId);
    }

    @Override
    public List<Conversation> getUserConversations(int userId) throws DatabaseException {
        return conversationDAO.findByUserId(userId);
    }

    @Override
    public ResponseEngine getResponseEngine() {
        return responseEngine;
    }
}
