package com.nexabot.dao;

import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.Conversation;
import com.nexabot.util.ConfigLoader;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Data Access Object for Conversation sessions.
 * Implements Generic Repository<Conversation, Integer>.
 */
public class ConversationDAO implements Repository<Conversation, Integer> {

    private final DatabaseConnection dbManager = DatabaseConnection.getInstance();
    private static final Map<Integer, Conversation> fallbackConversationMap = new ConcurrentHashMap<>();
    private static final AtomicInteger fallbackIdCounter = new AtomicInteger(10);

    @Override
    public Conversation save(Conversation conversation) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            if (conversation.getConversationId() == 0) {
                conversation.setConversationId(fallbackIdCounter.incrementAndGet());
                conversation.setStartedAt(new Timestamp(System.currentTimeMillis()));
            }
            fallbackConversationMap.put(conversation.getConversationId(), conversation);
            return conversation;
        }

        String sql = "INSERT INTO conversations (user_id, title) VALUES (?, ?)";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, conversation.getUserId());
            stmt.setString(2, conversation.getTitle());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        conversation.setConversationId(rs.getInt(1));
                    }
                }
            }
            conversation.setStartedAt(new Timestamp(System.currentTimeMillis()));
            fallbackConversationMap.put(conversation.getConversationId(), conversation);
            return conversation;
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                if (conversation.getConversationId() == 0) {
                    conversation.setConversationId(fallbackIdCounter.incrementAndGet());
                    conversation.setStartedAt(new Timestamp(System.currentTimeMillis()));
                }
                fallbackConversationMap.put(conversation.getConversationId(), conversation);
                return conversation;
            }
            throw new DatabaseException("Failed to save conversation: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    @Override
    public Optional<Conversation> findById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return Optional.ofNullable(fallbackConversationMap.get(id));
        }

        String sql = "SELECT conversation_id, user_id, title, started_at FROM conversations WHERE conversation_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToConversation(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find conversation: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return Optional.empty();
    }

    public List<Conversation> findByUserId(int userId) throws DatabaseException {
        List<Conversation> list = new ArrayList<>();
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackConversationMap.values().stream()
                    .filter(c -> c.getUserId() == userId)
                    .sorted((a, b) -> b.getConversationId() - a.getConversationId())
                    .collect(Collectors.toList());
        }

        String sql = "SELECT conversation_id, user_id, title, started_at FROM conversations WHERE user_id = ? ORDER BY started_at DESC";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToConversation(rs));
                }
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return fallbackConversationMap.values().stream()
                        .filter(c -> c.getUserId() == userId)
                        .collect(Collectors.toList());
            }
            throw new DatabaseException("Failed to load user conversations: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return list;
    }

    @Override
    public List<Conversation> findAll() throws DatabaseException {
        List<Conversation> list = new ArrayList<>();
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return new ArrayList<>(fallbackConversationMap.values());
        }

        String sql = "SELECT conversation_id, user_id, title, started_at FROM conversations ORDER BY started_at DESC";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToConversation(rs));
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return new ArrayList<>(fallbackConversationMap.values());
            }
            throw new DatabaseException("Failed to retrieve all conversations: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return list;
    }

    @Override
    public boolean deleteById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackConversationMap.remove(id) != null;
        }

        String sql = "DELETE FROM conversations WHERE conversation_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete conversation: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    private Conversation mapResultSetToConversation(ResultSet rs) throws SQLException {
        return new Conversation(
                rs.getInt("conversation_id"),
                rs.getInt("user_id"),
                rs.getString("title"),
                rs.getTimestamp("started_at")
        );
    }
}
