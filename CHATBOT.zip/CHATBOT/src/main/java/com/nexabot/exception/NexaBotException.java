package com.nexabot.exception;

/**
 * Base checked exception for the NexaBot application.
 * All custom application exceptions inherit from this class.
 */
public class NexaBotException extends Exception {
    
    public NexaBotException(String message) {
        super(message);
    }

    public NexaBotException(String message, Throwable cause) {
        super(message, cause);
    }
}
