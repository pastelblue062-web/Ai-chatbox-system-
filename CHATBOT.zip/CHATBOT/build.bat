@echo off
echo ===================================================
echo   Compiling NexaBot - AI Chatbot System
echo ===================================================

if not exist bin mkdir bin

echo Compiling Java source files...
javac -encoding UTF-8 -cp ".;lib\mysql-connector-j-8.3.0.jar;src\main\resources" -d bin src\main\java\com\nexabot\model\*.java src\main\java\com\nexabot\exception\*.java src\main\java\com\nexabot\util\*.java src\main\java\com\nexabot\database\*.java src\main\java\com\nexabot\dao\*.java src\main\java\com\nexabot\chatbot\*.java src\main\java\com\nexabot\strategy\*.java src\main\java\com\nexabot\concurrent\*.java src\main\java\com\nexabot\service\*.java src\main\java\com\nexabot\gui\*.java src\main\java\com\nexabot\*.java

if %ERRORLEVEL% equ 0 (
    echo [SUCCESS] Compilation completed without errors.
    echo Copying resources to bin...
    xcopy /y /e /i src\main\resources\* bin\ > nul
    echo Build Ready! Run run.bat to start NexaBot.
) else (
    echo [ERROR] Compilation failed. Please inspect errors above.
)
pause
