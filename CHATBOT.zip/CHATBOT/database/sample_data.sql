-- =======================================================
-- NexaBot - AI Chatbot System
-- Sample Seed Data
-- =======================================================

USE nexabot_db;

-- Clear previous sample entries
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE feedback;
TRUNCATE TABLE messages;
TRUNCATE TABLE conversations;
TRUNCATE TABLE knowledge_base;
TRUNCATE TABLE users;
SET FOREIGN_KEY_CHECKS = 1;

-- -------------------------------------------------------
-- Seed Users (Password for all is 'Admin@123' or 'User@123')
-- SHA-256 hash formatted as salt:hexhash
-- -------------------------------------------------------
INSERT INTO users (user_id, name, email, password, role) VALUES
(1, 'System Administrator', 'admin@nexabot.ai', 'e89547d7fa61587a:7b34f6ba5d9e504c5e3170e176b6fbcf2b5a6c117b9d5c8dc1e16f3984e1b8eb', 'ADMIN'),
(2, 'Arifa Firdous', 'arifa@nexabot.ai', 'e89547d7fa61587a:8bb06cb8f19da38805370335804369527fefae6023f46f3a677332ff0cf5e347', 'USER'),
(3, 'Muskan Pandey', 'muskan@nexabot.ai', 'e89547d7fa61587a:8bb06cb8f19da38805370335804369527fefae6023f46f3a677332ff0cf5e347', 'USER'),
(4, 'Rajvardhan Singh Parmar', 'rajvardhan@nexabot.ai', 'e89547d7fa61587a:8bb06cb8f19da38805370335804369527fefae6023f46f3a677332ff0cf5e347', 'USER');

-- -------------------------------------------------------
-- Seed Knowledge Base
-- -------------------------------------------------------
INSERT INTO knowledge_base (knowledge_id, intent, question, keywords, response) VALUES
(1, 'GREETING', 'Hello', 'hello,hi,hey,greetings,morning,afternoon,evening', 'Hello! Welcome to NexaBot. How can I assist you with your Java, OOP, or Database queries today?'),
(2, 'GREETING', 'How are you?', 'how,are,you,doing,status', 'I am running at optimal performance and ready to assist you with computer science and programming topics!'),
(3, 'GOODBYE', 'Bye', 'bye,goodbye,exit,see you,later,farewell', 'Goodbye! Have a productive coding session. Feel free to come back whenever you have questions!'),
(4, 'HELP', 'What can you do?', 'help,guide,topics,questions,features,commands', 'You can ask me about: Java concepts, OOP (Inheritance, Polymorphism, Encapsulation, Abstraction), JDBC, MySQL, Multithreading, Collections, Generics, and Project Information!'),
(5, 'THANK_YOU', 'Thank you', 'thanks,thank,appreciate,helpful,great', 'You are most welcome! Happy to assist. Do you have any other questions?'),

-- Core Java & OOP
(6, 'JAVA', 'What is Java?', 'java,platform,jdk,jvm,features', 'Java is a high-level, class-based, object-oriented programming language designed to have as few implementation dependencies as possible (Write Once, Run Anywhere via the JVM).'),
(7, 'OOP', 'What is OOP?', 'oop,object,oriented,programming,paradigm,principles', 'Object-Oriented Programming (OOP) is a paradigm organized around objects and classes rather than actions and logic. Its four key pillars are Encapsulation, Abstraction, Inheritance, and Polymorphism.'),
(8, 'INHERITANCE', 'What is inheritance?', 'inheritance,extends,subclass,superclass,parent,child', 'Inheritance is an OOP mechanism where one class (child/subclass) acquires properties and behaviors from another class (parent/superclass) using the "extends" keyword.'),
(9, 'POLYMORPHISM', 'What is polymorphism?', 'polymorphism,overloading,overriding,runtime,compiletime', 'Polymorphism allows objects to take on many forms. Java supports compile-time polymorphism (method overloading) and runtime polymorphism (method overriding via dynamic method dispatch).'),
(10, 'ENCAPSULATION', 'What is encapsulation?', 'encapsulation,data,hiding,private,getter,setter', 'Encapsulation is the bundling of data (fields) and methods that operate on that data into a single unit (class), while restricting direct access using private access modifiers and public getters/setters.'),
(11, 'ABSTRACTION', 'What is abstraction?', 'abstraction,abstract,interface,hiding,implementation', 'Abstraction hides internal implementation details and shows only the essential functionality to the user. It is achieved in Java using abstract classes and interfaces.'),

-- JDBC & Database
(12, 'JDBC', 'What is JDBC?', 'jdbc,database,connectivity,driver,connection', 'JDBC (Java Database Connectivity) is a standard Java API that connects Java applications to relational databases like MySQL, executing SQL queries and processing results.'),
(13, 'MYSQL', 'What is MySQL?', 'mysql,relational,rdbms,sql,tables', 'MySQL is an open-source Relational Database Management System (RDBMS) that stores structured data into tables using rows and columns, manipulated through SQL commands.'),
(14, 'PREPARED_STATEMENT', 'What is PreparedStatement?', 'preparedstatement,statement,sql,injection,parameterized', 'PreparedStatement is a precompiled SQL query interface in JDBC. It prevents SQL Injection vulnerabilities, supports parameterized queries, and optimizes query execution performance.'),

-- Collections & Generics
(15, 'COLLECTIONS', 'What is the Java Collections Framework?', 'collections,collection,list,set,map,arraylist,hashmap', 'The Java Collections Framework provides an architecture to store and manipulate groups of objects. Core interfaces include List (ordered), Set (unique items), and Map (key-value pairs).'),
(16, 'GENERICS', 'What are Java Generics?', 'generics,type,safety,generic,template,parameterized', 'Generics allow classes, interfaces, and methods to operate on parameterized types. They provide compile-time type safety, eliminate manual typecasting, and catch errors at compile time.'),

-- Concurrency & Threads
(17, 'MULTITHREADING', 'What is multithreading?', 'multithreading,thread,concurrency,runnable,executorservice', 'Multithreading is a Java feature that allows concurrent execution of two or more parts of a program for maximum CPU utilization. It can be created by extending Thread or implementing Runnable.'),
(18, 'SYNCHRONIZATION', 'What is synchronization in Java?', 'synchronization,synchronized,thread,safe,race,lock', 'Synchronization is the capability to control access of multiple threads to shared resources. Using the "synchronized" keyword prevents thread interference and race conditions.'),

-- Exceptions
(19, 'EXCEPTION_HANDLING', 'What is exception handling?', 'exception,handling,try,catch,finally,throw,throws', 'Exception handling is a mechanism in Java to handle runtime errors (like SQLException or NullPointerException), maintaining normal application flow using try, catch, finally, throw, and throws blocks.'),

-- Project Details
(20, 'PROJECT_INFO', 'Who developed NexaBot?', 'developer,team,author,created,project,nexabot,members', 'NexaBot was engineered by Arifa Firdous, Muskan Pandey, and Rajvardhan Singh Parmar as an academic Java Desktop AI Chatbot project.');

-- -------------------------------------------------------
-- Seed Sample Conversations & Messages
-- -------------------------------------------------------
INSERT INTO conversations (conversation_id, user_id, title) VALUES
(1, 2, 'Java Concepts Discussion'),
(2, 2, 'Database and JDBC Exploration');

INSERT INTO messages (message_id, conversation_id, user_id, user_message, bot_response, intent, confidence) VALUES
(1, 1, 2, 'Hello there!', 'Hello! Welcome to NexaBot. How can I assist you with your Java, OOP, or Database queries today?', 'GREETING', 0.95),
(2, 1, 2, 'What is Java?', 'Java is a high-level, class-based, object-oriented programming language designed to have as few implementation dependencies as possible (Write Once, Run Anywhere via the JVM).', 'JAVA', 1.00),
(3, 1, 2, 'What is inheritance in OOP?', 'Inheritance is an OOP mechanism where one class (child/subclass) acquires properties and behaviors from another class (parent/superclass) using the "extends" keyword.', 'INHERITANCE', 0.92),
(4, 2, 2, 'Can you explain JDBC?', 'JDBC (Java Database Connectivity) is a standard Java API that connects Java applications to relational databases like MySQL, executing SQL queries and processing results.', 'JDBC', 0.94),
(5, 2, 2, 'Who made this project?', 'NexaBot was engineered by Arifa Firdous, Muskan Pandey, and Rajvardhan Singh Parmar as an academic Java Desktop AI Chatbot project.', 'PROJECT_INFO', 0.98);

-- -------------------------------------------------------
-- Seed Feedback
-- -------------------------------------------------------
INSERT INTO feedback (feedback_id, message_id, user_id, rating, comment) VALUES
(1, 2, 2, 1, 'Very accurate definition of Java!'),
(2, 3, 2, 1, 'Clear explanation of OOP inheritance.'),
(3, 4, 2, 1, 'Understood JDBC immediately.');
