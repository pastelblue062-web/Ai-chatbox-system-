package com.nexabot.dao;

import com.nexabot.exception.DatabaseException;
import java.util.List;
import java.util.Optional;

/**
 * Generic Repository interface demonstrating Generics & Collections.
 *
 * @param <T>  The entity type
 * @param <ID> The primary key identifier type
 */
public interface Repository<T, ID> {

    /**
     * Persists or updates an entity.
     * @param entity The entity to save
     * @return The saved entity with generated ID populated
     * @throws DatabaseException if persistence fails
     */
    T save(T entity) throws DatabaseException;

    /**
     * Finds an entity by its primary key ID.
     * @param id The entity ID
     * @return Optional containing the entity if found
     * @throws DatabaseException if database query fails
     */
    Optional<T> findById(ID id) throws DatabaseException;

    /**
     * Retrieves all entities.
     * @return List of all entities (demonstrating Collections)
     * @throws DatabaseException if database query fails
     */
    List<T> findAll() throws DatabaseException;

    /**
     * Deletes an entity by primary key.
     * @param id The entity ID
     * @return true if deleted, false otherwise
     * @throws DatabaseException if database query fails
     */
    boolean deleteById(ID id) throws DatabaseException;
}
