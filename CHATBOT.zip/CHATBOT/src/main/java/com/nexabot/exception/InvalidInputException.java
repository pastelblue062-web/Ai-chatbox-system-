package com.nexabot.exception;

/**
 * Exception thrown when user input violates validation criteria
 * (e.g. empty messages, malformed email, short passwords).
 */
public class InvalidInputException extends NexaBotException {

    private final String fieldName;

    public InvalidInputException(String message) {
        super(message);
        this.fieldName = null;
    }

    public InvalidInputException(String fieldName, String message) {
        super(message);
        this.fieldName = fieldName;
    }

    public String getFieldName() {
        return fieldName;
    }
}
