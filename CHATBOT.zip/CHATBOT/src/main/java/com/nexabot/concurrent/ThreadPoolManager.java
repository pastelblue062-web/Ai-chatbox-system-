package com.nexabot.concurrent;

import java.util.concurrent.*;

/**
 * Thread Pool Manager handling asynchronous background tasks.
 * Ensures the Java Swing Event Dispatch Thread (EDT) never blocks or freezes
 * during database I/O or NLP computation.
 * Demonstrates:
 *  - Multithreading: ExecutorService, Future, Callable, Runnable
 */
public class ThreadPoolManager {

    private static volatile ThreadPoolManager instance;
    private final ExecutorService executorService;

    private ThreadPoolManager() {
        int corePoolSize = Math.max(2, Runtime.getRuntime().availableProcessors());
        this.executorService = new ThreadPoolExecutor(
                corePoolSize,
                corePoolSize * 2,
                60L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(100),
                new ThreadFactory() {
                    private int counter = 1;
                    @Override
                    public Thread newThread(Runnable r) {
                        Thread t = new Thread(r, "NexaBot-Worker-" + (counter++));
                        t.setDaemon(true);
                        return t;
                    }
                }
        );
    }

    public static ThreadPoolManager getInstance() {
        if (instance == null) {
            synchronized (ThreadPoolManager.class) {
                if (instance == null) {
                    instance = new ThreadPoolManager();
                }
            }
        }
        return instance;
    }

    public void execute(Runnable task) {
        executorService.execute(task);
    }

    public <T> Future<T> submit(Callable<T> task) {
        return executorService.submit(task);
    }

    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(3, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
