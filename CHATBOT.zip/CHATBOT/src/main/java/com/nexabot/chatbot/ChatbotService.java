package com.nexabot.chatbot;

import com.nexabot.exception.ChatbotProcessingException;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.ChatResponse;
import com.nexabot.model.Conversation;
import com.nexabot.model.Feedback;
import com.nexabot.model.Message;

import java.util.List;

/**
 * Service interface defining the chatbot operations contract.
 * Demonstrates:
 *  - Interfaces
 *  - Separation of Business Logic from presentation (Swing GUI)
 */
public interface ChatbotService {

    /**
     * Creates a new conversation record for the logged-in user.
     */
    Conversation startNewConversation(int userId, String title) throws DatabaseException;

    /**
     * Processes a user message through NLP and persists both query and response in the database.
     */
    Message processMessage(int conversationId, int userId, String userMessage)
            throws ChatbotProcessingException, DatabaseException;

    /**
     * Records user feedback (Helpful / Unhelpful) for a message.
     */
    Feedback submitFeedback(int messageId, int userId, int rating, String comment) throws DatabaseException;

    /**
     * Retrieves all messages belonging to a conversation session.
     */
    List<Message> getConversationMessages(int conversationId) throws DatabaseException;

    /**
     * Retrieves all past conversations initiated by a user.
     */
    List<Conversation> getUserConversations(int userId) throws DatabaseException;

    /**
     * Returns the underlying response engine.
     */
    ResponseEngine getResponseEngine();
}
