package com.nexabot.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Encapsulates aggregated metrics for the NexaBot Analytics Dashboard.
 * Demonstrates Collections: Map<String, Integer> for intent distribution tracking.
 */
public class AnalyticsData {
    private int totalUsers;
    private int totalConversations;
    private int totalMessages;
    private int helpfulCount;
    private int unhelpfulCount;
    private double averageConfidence;
    private String mostFrequentIntent;
    private Map<String, Integer> intentDistribution;

    public AnalyticsData() {
        this.intentDistribution = new HashMap<>();
    }

    public int getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(int totalUsers) {
        this.totalUsers = totalUsers;
    }

    public int getTotalConversations() {
        return totalConversations;
    }

    public void setTotalConversations(int totalConversations) {
        this.totalConversations = totalConversations;
    }

    public int getTotalMessages() {
        return totalMessages;
    }

    public void setTotalMessages(int totalMessages) {
        this.totalMessages = totalMessages;
    }

    public int getHelpfulCount() {
        return helpfulCount;
    }

    public void setHelpfulCount(int helpfulCount) {
        this.helpfulCount = helpfulCount;
    }

    public int getUnhelpfulCount() {
        return unhelpfulCount;
    }

    public void setUnhelpfulCount(int unhelpfulCount) {
        this.unhelpfulCount = unhelpfulCount;
    }

    public double getAverageConfidence() {
        return averageConfidence;
    }

    public void setAverageConfidence(double averageConfidence) {
        this.averageConfidence = averageConfidence;
    }

    public String getMostFrequentIntent() {
        return mostFrequentIntent != null ? mostFrequentIntent : "N/A";
    }

    public void setMostFrequentIntent(String mostFrequentIntent) {
        this.mostFrequentIntent = mostFrequentIntent;
    }

    public Map<String, Integer> getIntentDistribution() {
        return intentDistribution;
    }

    public void setIntentDistribution(Map<String, Integer> intentDistribution) {
        this.intentDistribution = intentDistribution != null ? intentDistribution : new HashMap<>();
    }

    public double getHelpfulPercentage() {
        int totalFeedback = helpfulCount + unhelpfulCount;
        if (totalFeedback == 0) return 0.0;
        return ((double) helpfulCount / totalFeedback) * 100.0;
    }

    @Override
    public String toString() {
        return "AnalyticsData[users=" + totalUsers + ", msgs=" + totalMessages + ", helpful=" + helpfulCount + ", avgConf=" + String.format("%.2f", averageConfidence) + "]";
    }
}
