# NexaBot - Architecture Specification

## 1. System Overview

**NexaBot** is a desktop AI Chatbot application built using **Java Swing**, **JDBC**, and **MySQL**. It employs an extensible Object-Oriented architecture adhering to industry-standard design patterns, clean separation of concerns, and robust multithreading.

---

## 2. Layered Architecture

NexaBot is structured into six discrete, decoupled layers:

```
┌────────────────────────────────────────────────────────┐
│                   Java Swing GUI Layer                 │
│  (LoginFrame, RegisterFrame, ChatFrame, HistoryFrame)  │
└──────────────────────────┬─────────────────────────────┘
                           │
┌──────────────────────────▼─────────────────────────────┐
│                      Service Layer                     │
│  (AuthenticationService, ChatbotService, Analytics)    │
└────────────┬─────────────────────────────┬─────────────┘
             │                             │
┌────────────▼─────────────┐ ┌─────────────▼─────────────┐
│      Chatbot Core        │ │     Data Access (DAO)     │
│  - TextProcessor (NLP)   │ │  - Repository<T, ID>      │
│  - IntentDetector        │ │  - UserDAO, MessageDAO    │
│  - ResponseEngine        │ │  - ConversationDAO        │
│  - Polymorphic Strategy  │ │  - FeedbackDAO, KB DAO    │
└──────────────────────────┘ └─────────────┬─────────────┘
                                           │
                             ┌─────────────▼─────────────┐
                             │       Database Layer      │
                             │  (DatabaseConnection/JDBC)│
                             └─────────────┬─────────────┘
                                           │
                             ┌─────────────▼─────────────┐
                             │        MySQL Server       │
                             │       (nexabot_db)        │
                             └───────────────────────────┘
```

---

## 3. Object-Oriented Principles Implementation

### 3.1 Encapsulation
Every model class (`User`, `Admin`, `RegularUser`, `Message`, `Conversation`, `Feedback`, `Intent`, `KnowledgeEntry`, `ChatResponse`) protects its state using `private` fields. State is exposed only through validated `getters` and `setters`.

### 3.2 Inheritance
A clean, meaningful hierarchy defines identity and permissions:
- `User` (Abstract base class containing universal user properties: `userId`, `name`, `email`, `password`, `createdAt`)
  - `RegularUser` (Restricted standard privileges)
  - `Admin` (Elevated privileges: knowledge base management, system analytics)

### 3.3 Polymorphism
Response generation relies on the Strategy Pattern:
- `ResponseStrategy` (Interface with `generateResponse(...)` and `canHandle(...)`)
  - `RuleBasedResponseStrategy` (Handles conversational greetings and commands)
  - `KeywordResponseStrategy` (Calculates token overlap and intent confidence)
  - `FallbackResponseStrategy` (Safely handles unknown queries with recommendations)

### 3.4 Interfaces
Explicit contracts decouple layers:
- `Repository<T, ID>`: Generic data persistence contract.
- `ChatbotService`: Chat session orchestration.
- `AuthenticationService`: Login, registration, and session contracts.
- `ResponseStrategy`: Dynamic AI response algorithm contract.

### 3.5 Custom Exceptions
A specialized hierarchy handles errors without crashing or empty catch blocks:
- `NexaBotException`
  - `DatabaseException` (SQL error details and codes)
  - `AuthenticationException` (Invalid credentials / unauthorized access)
  - `InvalidInputException` (Form validation & message length violations)
  - `ChatbotProcessingException` (NLP and tokenization failures)

---

## 4. Multithreading & Synchronization Model

- **Background Execution**: All NLP calculations, database operations, and statistics aggregations run off the Event Dispatch Thread (EDT) via `ThreadPoolManager` and `SwingWorker`.
- **UI Responsiveness**: A typing indicator is displayed while the background worker processes the query; user input remains smooth and non-blocking.
- **Synchronization**: `SharedMetricsMonitor` coordinates concurrent updates to total message counts, response latency metrics, and shared `Map<String, Integer>` intent frequencies using synchronized blocks and atomic primitives (`AtomicInteger`, `AtomicLong`).
