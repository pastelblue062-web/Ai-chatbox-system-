package com.nexabot.dao;

import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.KnowledgeEntry;
import com.nexabot.util.ConfigLoader;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Data Access Object for KnowledgeBase entries.
 * Implements Generic Repository<KnowledgeEntry, Integer>.
 * Allows dynamic runtime additions/updates by Administrators.
 */
public class KnowledgeBaseDAO implements Repository<KnowledgeEntry, Integer> {

    private final DatabaseConnection dbManager = DatabaseConnection.getInstance();
    private static final Map<Integer, KnowledgeEntry> fallbackKnowledgeMap = new ConcurrentHashMap<>();
    private static final AtomicInteger fallbackIdCounter = new AtomicInteger(30);

    static {
        // Built-in seed entries for guaranteed zero-dependency operation
        seedFallbackEntry(1, "GREETING", "Hello", "hello,hi,hey,greetings,morning",
                "Hello! Welcome to NexaBot. How can I assist you with your Java, OOP, or Database queries today?");
        seedFallbackEntry(2, "GOODBYE", "Bye", "bye,goodbye,exit,later,farewell",
                "Goodbye! Have a productive coding session. Feel free to come back whenever you have questions!");
        seedFallbackEntry(3, "HELP", "What can you do?", "help,guide,topics,questions,features,commands",
                "You can ask me about: Java concepts, OOP (Inheritance, Polymorphism, Encapsulation, Abstraction), JDBC, MySQL, Multithreading, Collections, Generics, and Project Information!");
        seedFallbackEntry(4, "THANK_YOU", "Thank you", "thanks,thank,appreciate,helpful,great",
                "You are most welcome! Happy to assist. Do you have any other questions?");
        seedFallbackEntry(5, "JAVA", "What is Java?", "java,platform,jdk,jvm,features",
                "Java is a high-level, class-based, object-oriented programming language designed to have as few implementation dependencies as possible (Write Once, Run Anywhere via the JVM).");
        seedFallbackEntry(6, "OOP", "What is OOP?", "oop,object,oriented,programming,paradigm,principles",
                "Object-Oriented Programming (OOP) is a paradigm organized around objects and classes rather than actions and logic. Its four key pillars are Encapsulation, Abstraction, Inheritance, and Polymorphism.");
        seedFallbackEntry(7, "INHERITANCE", "What is inheritance?", "inheritance,extends,subclass,superclass,parent,child",
                "Inheritance is an OOP mechanism where one class (child/subclass) acquires properties and behaviors from another class (parent/superclass) using the 'extends' keyword.");
        seedFallbackEntry(8, "POLYMORPHISM", "What is polymorphism?", "polymorphism,overloading,overriding,runtime,compiletime",
                "Polymorphism allows objects to take on many forms. Java supports compile-time polymorphism (method overloading) and runtime polymorphism (method overriding via dynamic method dispatch).");
        seedFallbackEntry(9, "ENCAPSULATION", "What is encapsulation?", "encapsulation,data,hiding,private,getter,setter",
                "Encapsulation is the bundling of data (fields) and methods that operate on that data into a single unit (class), while restricting direct access using private access modifiers and public getters/setters.");
        seedFallbackEntry(10, "ABSTRACTION", "What is abstraction?", "abstraction,abstract,interface,hiding,implementation",
                "Abstraction hides internal implementation details and shows only the essential functionality to the user. It is achieved in Java using abstract classes and interfaces.");
        seedFallbackEntry(11, "JDBC", "What is JDBC?", "jdbc,database,connectivity,driver,connection",
                "JDBC (Java Database Connectivity) is a standard Java API that connects Java applications to relational databases like MySQL, executing SQL queries and processing results.");
        seedFallbackEntry(12, "MYSQL", "What is MySQL?", "mysql,relational,rdbms,sql,tables",
                "MySQL is an open-source Relational Database Management System (RDBMS) that stores structured data into tables using rows and columns, manipulated through SQL commands.");
        seedFallbackEntry(13, "COLLECTIONS", "What is Java Collections Framework?", "collections,collection,list,set,map,arraylist,hashmap",
                "The Java Collections Framework provides an architecture to store and manipulate groups of objects. Core interfaces include List (ordered), Set (unique items), and Map (key-value pairs).");
        seedFallbackEntry(14, "GENERICS", "What are Java Generics?", "generics,type,safety,generic,template,parameterized",
                "Generics allow classes, interfaces, and methods to operate on parameterized types. They provide compile-time type safety, eliminate manual typecasting, and catch errors at compile time.");
        seedFallbackEntry(15, "MULTITHREADING", "What is multithreading?", "multithreading,thread,concurrency,runnable,executorservice",
                "Multithreading is a Java feature that allows concurrent execution of two or more parts of a program for maximum CPU utilization. It can be created by extending Thread or implementing Runnable.");
        seedFallbackEntry(16, "SYNCHRONIZATION", "What is synchronization in Java?", "synchronization,synchronized,thread,safe,race,lock",
                "Synchronization is the capability to control access of multiple threads to shared resources. Using the 'synchronized' keyword prevents thread interference and race conditions.");
        seedFallbackEntry(17, "EXCEPTION_HANDLING", "What is exception handling?", "exception,handling,try,catch,finally,throw,throws",
                "Exception handling is a mechanism in Java to handle runtime errors (like SQLException or NullPointerException), maintaining normal application flow using try, catch, finally, throw, and throws blocks.");
        seedFallbackEntry(18, "PROJECT_INFO", "Who developed NexaBot?", "developer,team,author,created,project,nexabot,members",
                "NexaBot was engineered by Arifa Firdous, Muskan Pandey, and Rajvardhan Singh Parmar as an academic Java Desktop AI Chatbot project.");
    }

    private static void seedFallbackEntry(int id, String intent, String q, String kw, String resp) {
        fallbackKnowledgeMap.put(id, new KnowledgeEntry(id, intent, q, kw, resp, new Timestamp(System.currentTimeMillis())));
    }

    @Override
    public KnowledgeEntry save(KnowledgeEntry entry) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            if (entry.getKnowledgeId() == 0) {
                entry.setKnowledgeId(fallbackIdCounter.incrementAndGet());
                entry.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            }
            fallbackKnowledgeMap.put(entry.getKnowledgeId(), entry);
            return entry;
        }

        String sql = "INSERT INTO knowledge_base (intent, question, keywords, response) VALUES (?, ?, ?, ?)";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, entry.getIntent());
            stmt.setString(2, entry.getQuestion());
            stmt.setString(3, entry.getKeywords());
            stmt.setString(4, entry.getResponse());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        entry.setKnowledgeId(rs.getInt(1));
                    }
                }
            }
            entry.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            fallbackKnowledgeMap.put(entry.getKnowledgeId(), entry);
            return entry;
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                if (entry.getKnowledgeId() == 0) {
                    entry.setKnowledgeId(fallbackIdCounter.incrementAndGet());
                    entry.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                }
                fallbackKnowledgeMap.put(entry.getKnowledgeId(), entry);
                return entry;
            }
            throw new DatabaseException("Failed to save knowledge base entry: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    @Override
    public Optional<KnowledgeEntry> findById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return Optional.ofNullable(fallbackKnowledgeMap.get(id));
        }

        String sql = "SELECT knowledge_id, intent, question, keywords, response, created_at FROM knowledge_base WHERE knowledge_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToEntry(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to query knowledge entry: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<KnowledgeEntry> findAll() throws DatabaseException {
        List<KnowledgeEntry> list = new ArrayList<>();
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return new ArrayList<>(fallbackKnowledgeMap.values());
        }

        String sql = "SELECT knowledge_id, intent, question, keywords, response, created_at FROM knowledge_base ORDER BY knowledge_id ASC";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToEntry(rs));
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return new ArrayList<>(fallbackKnowledgeMap.values());
            }
            throw new DatabaseException("Failed to retrieve knowledge base entries: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }

        // If database was empty, populate with fallback defaults
        if (list.isEmpty()) {
            list.addAll(fallbackKnowledgeMap.values());
        }
        return list;
    }

    @Override
    public boolean deleteById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackKnowledgeMap.remove(id) != null;
        }

        String sql = "DELETE FROM knowledge_base WHERE knowledge_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete knowledge entry: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    public List<KnowledgeEntry> search(String query) throws DatabaseException {
        if (query == null || query.trim().isEmpty()) {
            return findAll();
        }
        String q = query.trim().toLowerCase();
        return findAll().stream()
                .filter(e -> e.getQuestion().toLowerCase().contains(q)
                        || e.getKeywords().toLowerCase().contains(q)
                        || e.getIntent().toLowerCase().contains(q))
                .collect(Collectors.toList());
    }

    private KnowledgeEntry mapResultSetToEntry(ResultSet rs) throws SQLException {
        return new KnowledgeEntry(
                rs.getInt("knowledge_id"),
                rs.getString("intent"),
                rs.getString("question"),
                rs.getString("keywords"),
                rs.getString("response"),
                rs.getTimestamp("created_at")
        );
    }
}
