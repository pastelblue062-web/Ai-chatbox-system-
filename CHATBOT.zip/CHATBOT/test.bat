@echo off
echo ===================================================
echo   Running NexaBot Automated Verification Suite
echo ===================================================

javac -encoding UTF-8 -cp ".;bin;lib\mysql-connector-j-8.3.0.jar;src\main\resources" -d bin src\test\java\com\nexabot\ChatbotTestSuite.java
java -cp ".;bin;lib\mysql-connector-j-8.3.0.jar;src\main\resources" com.nexabot.ChatbotTestSuite
pause
