package com.nexabot;

import com.nexabot.concurrent.ThreadPoolManager;
import com.nexabot.database.DatabaseConnection;
import com.nexabot.gui.LoginFrame;

import javax.swing.*;

/**
 * Main application launcher for NexaBot - AI Chatbot System.
 *
 * Project: AI Chatbot System (NexaBot)
 * Academic Submission: Second-Year Java GUI + MySQL + NLP Project
 * Team Members:
 *  1. Arifa Firdous
 *  2. Muskan Pandey
 *  3. Rajvardhan Singh Parmar
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("  🤖 NexaBot - AI Chatbot System Starting Up...  ");
        System.out.println("  Developed by: Arifa Firdous, Muskan Pandey,     ");
        System.out.println("                Rajvardhan Singh Parmar          ");
        System.out.println("=================================================");

        // Set modern Look and Feel with text anti-aliasing
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            System.setProperty("awt.useSystemAAFontSettings", "on");
            System.setProperty("swing.aatext", "true");
        } catch (Exception e) {
            System.err.println("[Main] Could not set System Look and Feel: " + e.getMessage());
        }

        // Test database connection in background
        ThreadPoolManager.getInstance().execute(() -> {
            boolean connected = DatabaseConnection.getInstance().isConnected();
            if (connected) {
                System.out.println("[Main] MySQL Database Connected Successfully.");
            } else {
                System.out.println("[Main] MySQL not detected. NexaBot is active in High-Resilience In-Memory Mode.");
            }
        });

        // Register clean JVM shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("[Main] Shutting down NexaBot resources...");
            DatabaseConnection.getInstance().closeConnection();
            ThreadPoolManager.getInstance().shutdown();
            System.out.println("[Main] Shutdown complete.");
        }));

        // Launch GUI on Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
