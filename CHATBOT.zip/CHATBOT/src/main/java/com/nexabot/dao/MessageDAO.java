package com.nexabot.dao;

import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.Message;
import com.nexabot.util.ConfigLoader;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Data Access Object for Message entities.
 * Implements Generic Repository<Message, Integer>.
 */
public class MessageDAO implements Repository<Message, Integer> {

    private final DatabaseConnection dbManager = DatabaseConnection.getInstance();
    private static final Map<Integer, Message> fallbackMessageMap = new ConcurrentHashMap<>();
    private static final AtomicInteger fallbackIdCounter = new AtomicInteger(20);

    @Override
    public Message save(Message message) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            if (message.getMessageId() == 0) {
                message.setMessageId(fallbackIdCounter.incrementAndGet());
                message.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            }
            fallbackMessageMap.put(message.getMessageId(), message);
            return message;
        }

        String sql = "INSERT INTO messages (conversation_id, user_id, user_message, bot_response, intent, confidence) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, message.getConversationId());
            stmt.setInt(2, message.getUserId());
            stmt.setString(3, message.getUserMessage());
            stmt.setString(4, message.getBotResponse());
            stmt.setString(5, message.getIntent());
            stmt.setDouble(6, message.getConfidence());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        message.setMessageId(rs.getInt(1));
                    }
                }
            }
            message.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            fallbackMessageMap.put(message.getMessageId(), message);
            return message;
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                if (message.getMessageId() == 0) {
                    message.setMessageId(fallbackIdCounter.incrementAndGet());
                    message.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                }
                fallbackMessageMap.put(message.getMessageId(), message);
                return message;
            }
            throw new DatabaseException("Failed to save message: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    @Override
    public Optional<Message> findById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return Optional.ofNullable(fallbackMessageMap.get(id));
        }

        String sql = "SELECT message_id, conversation_id, user_id, user_message, bot_response, intent, confidence, created_at FROM messages WHERE message_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToMessage(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find message: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return Optional.empty();
    }

    public List<Message> findByConversationId(int conversationId) throws DatabaseException {
        List<Message> list = new ArrayList<>();
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackMessageMap.values().stream()
                    .filter(m -> m.getConversationId() == conversationId)
                    .sorted(Comparator.comparingInt(Message::getMessageId))
                    .collect(Collectors.toList());
        }

        String sql = "SELECT message_id, conversation_id, user_id, user_message, bot_response, intent, confidence, created_at FROM messages WHERE conversation_id = ? ORDER BY message_id ASC";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, conversationId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToMessage(rs));
                }
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return fallbackMessageMap.values().stream()
                        .filter(m -> m.getConversationId() == conversationId)
                        .collect(Collectors.toList());
            }
            throw new DatabaseException("Failed to retrieve conversation messages: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return list;
    }

    @Override
    public List<Message> findAll() throws DatabaseException {
        List<Message> list = new ArrayList<>();
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return new ArrayList<>(fallbackMessageMap.values());
        }

        String sql = "SELECT message_id, conversation_id, user_id, user_message, bot_response, intent, confidence, created_at FROM messages ORDER BY message_id DESC";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToMessage(rs));
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return new ArrayList<>(fallbackMessageMap.values());
            }
            throw new DatabaseException("Failed to retrieve messages: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return list;
    }

    @Override
    public boolean deleteById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackMessageMap.remove(id) != null;
        }

        String sql = "DELETE FROM messages WHERE message_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete message: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    private Message mapResultSetToMessage(ResultSet rs) throws SQLException {
        return new Message(
                rs.getInt("message_id"),
                rs.getInt("conversation_id"),
                rs.getInt("user_id"),
                rs.getString("user_message"),
                rs.getString("bot_response"),
                rs.getString("intent"),
                rs.getDouble("confidence"),
                rs.getTimestamp("created_at")
        );
    }
}
