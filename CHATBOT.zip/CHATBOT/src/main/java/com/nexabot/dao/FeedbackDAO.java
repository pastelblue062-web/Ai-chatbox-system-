package com.nexabot.dao;

import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.Feedback;
import com.nexabot.util.ConfigLoader;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Data Access Object for Feedback entities.
 * Implements Generic Repository<Feedback, Integer>.
 */
public class FeedbackDAO implements Repository<Feedback, Integer> {

    private final DatabaseConnection dbManager = DatabaseConnection.getInstance();
    private static final Map<Integer, Feedback> fallbackFeedbackMap = new ConcurrentHashMap<>();
    private static final AtomicInteger fallbackIdCounter = new AtomicInteger(10);

    @Override
    public Feedback save(Feedback feedback) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            if (feedback.getFeedbackId() == 0) {
                feedback.setFeedbackId(fallbackIdCounter.incrementAndGet());
                feedback.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            }
            fallbackFeedbackMap.put(feedback.getFeedbackId(), feedback);
            return feedback;
        }

        String sql = "INSERT INTO feedback (message_id, user_id, rating, comment) VALUES (?, ?, ?, ?)";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, feedback.getMessageId());
            stmt.setInt(2, feedback.getUserId());
            stmt.setInt(3, feedback.getRating());
            stmt.setString(4, feedback.getComment());

            int affected = stmt.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        feedback.setFeedbackId(rs.getInt(1));
                    }
                }
            }
            feedback.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            fallbackFeedbackMap.put(feedback.getFeedbackId(), feedback);
            return feedback;
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                if (feedback.getFeedbackId() == 0) {
                    feedback.setFeedbackId(fallbackIdCounter.incrementAndGet());
                    feedback.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                }
                fallbackFeedbackMap.put(feedback.getFeedbackId(), feedback);
                return feedback;
            }
            throw new DatabaseException("Failed to save feedback: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    @Override
    public Optional<Feedback> findById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return Optional.ofNullable(fallbackFeedbackMap.get(id));
        }

        String sql = "SELECT feedback_id, message_id, user_id, rating, comment, created_at FROM feedback WHERE feedback_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToFeedback(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find feedback: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<Feedback> findAll() throws DatabaseException {
        List<Feedback> list = new ArrayList<>();
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return new ArrayList<>(fallbackFeedbackMap.values());
        }

        String sql = "SELECT feedback_id, message_id, user_id, rating, comment, created_at FROM feedback ORDER BY created_at DESC";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToFeedback(rs));
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return new ArrayList<>(fallbackFeedbackMap.values());
            }
            throw new DatabaseException("Failed to retrieve feedback list: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return list;
    }

    @Override
    public boolean deleteById(Integer id) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackFeedbackMap.remove(id) != null;
        }

        String sql = "DELETE FROM feedback WHERE feedback_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete feedback: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    private Feedback mapResultSetToFeedback(ResultSet rs) throws SQLException {
        return new Feedback(
                rs.getInt("feedback_id"),
                rs.getInt("message_id"),
                rs.getInt("user_id"),
                rs.getInt("rating"),
                rs.getString("comment"),
                rs.getTimestamp("created_at")
        );
    }
}
