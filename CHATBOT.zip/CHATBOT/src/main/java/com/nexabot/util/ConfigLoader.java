package com.nexabot.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * Utility class to safely load configuration properties.
 * Avoids hardcoding database credentials inside the source code.
 */
public class ConfigLoader {
    private static final Properties properties = new Properties();
    private static boolean isLoaded = false;

    static {
        loadProperties();
    }

    private static synchronized void loadProperties() {
        if (isLoaded) return;

        // 1. First attempt loading from local external file if present (e.g. config.properties in working dir)
        File externalConfig = new File("config.properties");
        if (externalConfig.exists()) {
            try (InputStream is = new FileInputStream(externalConfig)) {
                properties.load(is);
                isLoaded = true;
                return;
            } catch (Exception ignored) {
            }
        }

        // 2. Next attempt loading from classpath resources
        try (InputStream is = ConfigLoader.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (is != null) {
                properties.load(is);
                isLoaded = true;
                return;
            }
        } catch (Exception ignored) {
        }

        // 3. Fallback defaults if configuration file is absent
        properties.setProperty("db.host", "localhost");
        properties.setProperty("db.port", "3306");
        properties.setProperty("db.name", "nexabot_db");
        properties.setProperty("db.user", "root");
        properties.setProperty("db.password", "root");
        properties.setProperty("db.demo_fallback", "true");
        isLoaded = true;
    }

    public static String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public static String getProperty(String key) {
        return properties.getProperty(key);
    }

    public static int getIntProperty(String key, int defaultValue) {
        String val = properties.getProperty(key);
        if (val != null) {
            try {
                return Integer.parseInt(val.trim());
            } catch (NumberFormatException ignored) {
            }
        }
        return defaultValue;
    }

    public static boolean getBooleanProperty(String key, boolean defaultValue) {
        String val = properties.getProperty(key);
        if (val != null) {
            return Boolean.parseBoolean(val.trim());
        }
        return defaultValue;
    }
}
