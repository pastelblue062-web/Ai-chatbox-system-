package com.nexabot.chatbot;

import com.nexabot.model.ChatResponse;
import com.nexabot.strategy.FallbackResponseStrategy;
import com.nexabot.strategy.KeywordResponseStrategy;
import com.nexabot.strategy.ResponseStrategy;
import com.nexabot.strategy.RuleBasedResponseStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Dedicated Response Engine.
 * Demonstrates:
 *  - Polymorphism: Orchestrates a collection of ResponseStrategy implementations.
 *  - Encapsulation & Separation of Concerns: Keeps bot AI response logic clean from GUI.
 */
public class ResponseEngine {

    private final TextProcessor textProcessor;
    private final KnowledgeBase knowledgeBase;
    private final List<ResponseStrategy> strategies;

    public ResponseEngine(KnowledgeBase knowledgeBase) {
        this.textProcessor = new TextProcessor();
        this.knowledgeBase = knowledgeBase;
        this.strategies = new ArrayList<>();

        // Register polymorphic strategies in order of evaluation priority
        this.strategies.add(new RuleBasedResponseStrategy());
        this.strategies.add(new KeywordResponseStrategy());
        this.strategies.add(new FallbackResponseStrategy()); // Final safety net
    }

    /**
     * Processes input string through NLP pipeline and generates a response.
     */
    public ChatResponse process(String rawMessage) {
        String cleaned = textProcessor.cleanText(rawMessage);
        List<String> tokensList = textProcessor.tokenize(cleaned);
        Set<String> keywordTokens = textProcessor.extractKeywords(tokensList);

        // Select the first eligible strategy (Polymorphic dispatch)
        for (ResponseStrategy strategy : strategies) {
            if (strategy.canHandle(keywordTokens, knowledgeBase)) {
                return strategy.generateResponse(rawMessage, cleaned, keywordTokens, knowledgeBase);
            }
        }

        // Guaranteed fallback
        return new FallbackResponseStrategy().generateResponse(rawMessage, cleaned, keywordTokens, knowledgeBase);
    }

    public KnowledgeBase getKnowledgeBase() {
        return knowledgeBase;
    }

    public TextProcessor getTextProcessor() {
        return textProcessor;
    }
}
