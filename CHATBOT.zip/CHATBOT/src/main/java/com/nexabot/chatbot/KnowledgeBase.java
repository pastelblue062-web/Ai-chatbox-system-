package com.nexabot.chatbot;

import com.nexabot.dao.KnowledgeBaseDAO;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.Intent;
import com.nexabot.model.KnowledgeEntry;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Knowledge Base Layer.
 * Demonstrates:
 *  - Collections: Map<String, Intent>, Set<String>, List<KnowledgeEntry>
 *  - Thread safety & Synchronization: synchronized methods and ConcurrentHashMap
 *  - Extensible intent architecture.
 */
public class KnowledgeBase {

    private final KnowledgeBaseDAO knowledgeBaseDAO;
    private final Map<String, Intent> intentMap;

    public KnowledgeBase() {
        this.knowledgeBaseDAO = new KnowledgeBaseDAO();
        this.intentMap = new ConcurrentHashMap<>();
        reloadFromDatabase();
    }

    /**
     * Synchronously loads all intents and Q&A entries from database or fallback.
     */
    public synchronized void reloadFromDatabase() {
        try {
            List<KnowledgeEntry> entries = knowledgeBaseDAO.findAll();
            intentMap.clear();

            for (KnowledgeEntry entry : entries) {
                String intentName = entry.getIntent().toUpperCase();
                Intent intent = intentMap.computeIfAbsent(intentName, k -> {
                    Intent newIntent = new Intent();
                    newIntent.setIntentName(intentName);
                    return newIntent;
                });

                // Parse and add keywords
                if (entry.getKeywords() != null) {
                    String[] kwArray = entry.getKeywords().split(",");
                    for (String kw : kwArray) {
                        intent.addKeyword(kw.trim().toLowerCase());
                    }
                }

                // Add example question and response
                intent.addExampleQuestion(entry.getQuestion());
                intent.addResponse(entry.getResponse());
            }
            System.out.println("[KnowledgeBase] Loaded " + intentMap.size() + " intents with " + entries.size() + " entries.");
        } catch (DatabaseException e) {
            System.err.println("[KnowledgeBase] Failed to load from database, initializing built-in defaults: " + e.getMessage());
            initBuiltInDefaults();
        }
    }

    private void initBuiltInDefaults() {
        // Fallback default intent definitions
        registerIntent("GREETING", Arrays.asList("hello", "hi", "hey", "greetings"),
                "Hello! Welcome to NexaBot. How can I assist you with your Java, OOP, or Database queries today?");
        registerIntent("GOODBYE", Arrays.asList("bye", "goodbye", "exit", "farewell"),
                "Goodbye! Have a productive coding session. Feel free to return if you have more questions!");
        registerIntent("JAVA", Arrays.asList("java", "jvm", "jdk", "platform"),
                "Java is a high-level, class-based, object-oriented programming language designed for platform independence (Write Once, Run Anywhere).");
        registerIntent("OOP", Arrays.asList("oop", "object", "oriented", "classes"),
                "OOP stands for Object-Oriented Programming. It organizes software design around objects and classes. The four main pillars are Encapsulation, Abstraction, Inheritance, and Polymorphism.");
        registerIntent("INHERITANCE", Arrays.asList("inheritance", "extends", "subclass", "superclass"),
                "Inheritance is an OOP mechanism where one class acquires the properties and methods of another class using the 'extends' keyword.");
        registerIntent("POLYMORPHISM", Arrays.asList("polymorphism", "overloading", "overriding"),
                "Polymorphism allows objects to take on multiple forms. Java supports compile-time polymorphism (overloading) and runtime polymorphism (overriding).");
        registerIntent("ENCAPSULATION", Arrays.asList("encapsulation", "private", "getter", "setter"),
                "Encapsulation is the technique of keeping fields private and providing access via public getter and setter methods.");
        registerIntent("ABSTRACTION", Arrays.asList("abstraction", "abstract", "interface"),
                "Abstraction hides the implementation details and displays only essential features to the user via abstract classes and interfaces.");
        registerIntent("JDBC", Arrays.asList("jdbc", "database", "connection", "sql"),
                "JDBC (Java Database Connectivity) is an API that enables Java programs to connect to relational databases like MySQL and execute SQL queries.");
        registerIntent("COLLECTIONS", Arrays.asList("collections", "list", "set", "map", "arraylist"),
                "The Java Collections Framework provides interfaces and classes (List, Set, Map) to store and manipulate groups of objects efficiently.");
        registerIntent("GENERICS", Arrays.asList("generics", "parameterized", "typesafety"),
                "Generics allow you to write classes, interfaces, and methods with type parameters, providing compile-time type safety.");
        registerIntent("MULTITHREADING", Arrays.asList("multithreading", "thread", "concurrency", "runnable"),
                "Multithreading enables concurrent execution of multiple parts of a program for maximum CPU efficiency.");
        registerIntent("SYNCHRONIZATION", Arrays.asList("synchronization", "synchronized", "threadsafe", "lock"),
                "Synchronization in Java controls the access of multiple threads to shared resources, preventing race conditions.");
        registerIntent("EXCEPTION_HANDLING", Arrays.asList("exception", "try", "catch", "throw", "throws"),
                "Exception handling manages runtime errors using try-catch blocks to prevent application crashes.");
        registerIntent("PROJECT_INFO", Arrays.asList("team", "developer", "author", "nexabot", "members"),
                "NexaBot was engineered by Arifa Firdous, Muskan Pandey, and Rajvardhan Singh Parmar as an academic Java Desktop AI Chatbot project.");
    }

    private void registerIntent(String name, List<String> keywords, String response) {
        Intent intent = new Intent();
        intent.setIntentName(name);
        for (String kw : keywords) {
            intent.addKeyword(kw);
        }
        intent.addResponse(response);
        intentMap.put(name, intent);
    }

    public synchronized Map<String, Intent> getAllIntents() {
        return Collections.unmodifiableMap(intentMap);
    }

    public synchronized Intent getIntent(String intentName) {
        if (intentName == null) return null;
        return intentMap.get(intentName.toUpperCase());
    }

    public synchronized void addOrUpdateIntent(Intent intent) {
        if (intent != null && intent.getIntentName() != null) {
            intentMap.put(intent.getIntentName().toUpperCase(), intent);
        }
    }
}
