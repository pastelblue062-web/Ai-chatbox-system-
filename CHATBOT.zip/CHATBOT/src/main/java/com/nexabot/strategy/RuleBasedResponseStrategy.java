package com.nexabot.strategy;

import com.nexabot.chatbot.KnowledgeBase;
import com.nexabot.model.ChatResponse;

import java.util.Set;

/**
 * Rule-based pattern matching strategy for conversational heuristics and direct bot commands.
 * Demonstrates Polymorphism (implements ResponseStrategy).
 */
public class RuleBasedResponseStrategy implements ResponseStrategy {

    @Override
    public boolean canHandle(Set<String> tokens, KnowledgeBase knowledgeBase) {
        if (tokens == null) return false;
        return tokens.contains("help") || tokens.contains("guide")
                || tokens.contains("hello") || tokens.contains("hi") || tokens.contains("hey")
                || tokens.contains("bye") || tokens.contains("goodbye")
                || tokens.contains("who") && tokens.contains("you")
                || tokens.contains("team") || tokens.contains("creator") || tokens.contains("developer");
    }

    @Override
    public ChatResponse generateResponse(String rawInput, String cleanedInput, Set<String> tokens, KnowledgeBase knowledgeBase) {
        long start = System.currentTimeMillis();
        String respText;
        String intent;
        double confidence = 0.98;

        if (tokens.contains("hello") || tokens.contains("hi") || tokens.contains("hey")) {
            respText = "Hello! Welcome to NexaBot. How can I assist you with your Java, OOP, or Database queries today?";
            intent = "GREETING";
        } else if (tokens.contains("bye") || tokens.contains("goodbye")) {
            respText = "Goodbye! Best of luck with your software engineering studies!";
            intent = "GOODBYE";
        } else if (tokens.contains("team") || tokens.contains("creator") || tokens.contains("developer")
                || (tokens.contains("who") && tokens.contains("made"))) {
            respText = "NexaBot was engineered by Arifa Firdous, Muskan Pandey, and Rajvardhan Singh Parmar as an academic Java Desktop AI Chatbot project.";
            intent = "PROJECT_INFO";
        } else if (tokens.contains("help") || tokens.contains("guide")) {
            respText = "NexaBot Help Guide:\n"
                    + "• Ask concept definitions (e.g., 'What is OOP?', 'Explain JDBC')\n"
                    + "• Explore Java pillars (Inheritance, Polymorphism, Encapsulation, Abstraction)\n"
                    + "• Review Concurrency (Multithreading, Synchronization)\n"
                    + "• Use the 👍 Helpful and 👎 Not Helpful buttons to rate answers!";
            intent = "HELP";
        } else {
            respText = "I am NexaBot, your intelligent academic Java assistant.";
            intent = "BOT_INFO";
            confidence = 0.90;
        }

        ChatResponse response = new ChatResponse(respText, intent, confidence, getStrategyName());
        response.setResponseTimeMs(System.currentTimeMillis() - start);
        return response;
    }

    @Override
    public String getStrategyName() {
        return "RuleBasedResponseStrategy";
    }
}
