package com.nexabot.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Model class encapsulating a complete chat conversation session.
 * Utilizes Java Collections (List<Message>).
 */
public class Conversation {
    private int conversationId;
    private int userId;
    private String title;
    private Timestamp startedAt;
    private List<Message> messages;

    public Conversation() {
        this.messages = new ArrayList<>();
    }

    public Conversation(int conversationId, int userId, String title, Timestamp startedAt) {
        this.conversationId = conversationId;
        this.userId = userId;
        this.title = title;
        this.startedAt = startedAt;
        this.messages = new ArrayList<>();
    }

    public Conversation(int userId, String title) {
        this.userId = userId;
        this.title = title;
        this.messages = new ArrayList<>();
    }

    public int getConversationId() {
        return conversationId;
    }

    public void setConversationId(int conversationId) {
        this.conversationId = conversationId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Timestamp getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Timestamp startedAt) {
        this.startedAt = startedAt;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages != null ? messages : new ArrayList<>();
    }

    public void addMessage(Message message) {
        if (message != null) {
            this.messages.add(message);
        }
    }

    @Override
    public String toString() {
        return "Conversation[id=" + conversationId + ", title='" + title + "', messageCount=" + messages.size() + "]";
    }
}
