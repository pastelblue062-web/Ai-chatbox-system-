package com.nexabot.concurrent;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Thread-safe shared metrics monitor accessed concurrently across multiple worker threads.
 * Demonstrates:
 *  - Multithreading Synchronization: synchronized methods and synchronized blocks
 *  - Thread safety using Atomic variables (AtomicInteger, AtomicLong)
 *  - Concurrent collections aggregation
 */
public class SharedMetricsMonitor {

    private static volatile SharedMetricsMonitor instance;

    private final AtomicInteger totalMessagesProcessed = new AtomicInteger(0);
    private final AtomicInteger activeBackgroundWorkers = new AtomicInteger(0);
    private final AtomicLong cumulativeResponseTimeMs = new AtomicLong(0);

    // Shared resource protected by synchronization
    private final Map<String, Integer> intentFrequencyMap = new HashMap<>();

    private SharedMetricsMonitor() {
    }

    public static SharedMetricsMonitor getInstance() {
        if (instance == null) {
            synchronized (SharedMetricsMonitor.class) {
                if (instance == null) {
                    instance = new SharedMetricsMonitor();
                }
            }
        }
        return instance;
    }

    /**
     * Records a completed message exchange in a thread-safe manner.
     * Demonstrates explicit block synchronization on a shared resource.
     */
    public void recordMessageExchange(String intent, long processingTimeMs) {
        totalMessagesProcessed.incrementAndGet();
        cumulativeResponseTimeMs.addAndGet(processingTimeMs);

        // Synchronize on the shared map to prevent concurrent modification and race conditions
        synchronized (intentFrequencyMap) {
            String key = (intent != null && !intent.isEmpty()) ? intent.toUpperCase() : "UNKNOWN";
            intentFrequencyMap.put(key, intentFrequencyMap.getOrDefault(key, 0) + 1);
        }
    }

    public void incrementWorkerCount() {
        activeBackgroundWorkers.incrementAndGet();
    }

    public void decrementWorkerCount() {
        activeBackgroundWorkers.decrementAndGet();
    }

    public int getActiveWorkerCount() {
        return activeBackgroundWorkers.get();
    }

    public int getTotalMessagesProcessed() {
        return totalMessagesProcessed.get();
    }

    public double getAverageResponseTimeMs() {
        int count = totalMessagesProcessed.get();
        if (count == 0) return 0.0;
        return (double) cumulativeResponseTimeMs.get() / count;
    }

    /**
     * Retrieves an immutable snapshot of intent frequencies.
     * Demonstrates synchronized read lock semantics.
     */
    public synchronized Map<String, Integer> getIntentFrequencySnapshot() {
        synchronized (intentFrequencyMap) {
            return Collections.unmodifiableMap(new HashMap<>(intentFrequencyMap));
        }
    }
}
