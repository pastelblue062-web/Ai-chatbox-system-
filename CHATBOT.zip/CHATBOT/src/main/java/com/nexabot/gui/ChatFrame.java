package com.nexabot.gui;

import com.nexabot.chatbot.ChatbotService;
import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.Conversation;
import com.nexabot.model.Message;
import com.nexabot.model.User;
import com.nexabot.service.AuthenticationService;
import com.nexabot.service.ChatbotServiceImpl;
import com.nexabot.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Main Chatbot GUI Frame.
 * Incorporates modern aesthetics, speech bubbles, feedback rating, and multithreading.
 */
public class ChatFrame extends JFrame {

    private final User currentUser;
    private final AuthenticationService authService;
    private final ChatbotService chatbotService;
    private Conversation currentConversation;
    private int lastMessageId = 0;

    private JPanel chatMessagesPanel;
    private JScrollPane scrollPane;
    private JTextField inputField;
    private JButton sendBtn;
    private JButton helpfulBtn;
    private JButton unhelpfulBtn;
    private JLabel feedbackStatusLabel;
    private JLabel typingIndicator;

    public ChatFrame(User currentUser, AuthenticationService authService) {
        this.currentUser = currentUser;
        this.authService = authService;
        this.chatbotService = new ChatbotServiceImpl();
        initUI();
        initConversation();
    }

    private void initUI() {
        setTitle("NexaBot - AI Chatbot System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(920, 720);
        setMinimumSize(new Dimension(800, 600));
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(UITheme.BG_DARK);

        // 1. Top Navigation Bar
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);

        // 2. Chat Viewport Area
        chatMessagesPanel = new JPanel();
        chatMessagesPanel.setLayout(new BoxLayout(chatMessagesPanel, BoxLayout.Y_AXIS));
        chatMessagesPanel.setBackground(UITheme.BG_DARK);
        chatMessagesPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        scrollPane = new JScrollPane(chatMessagesPanel);
        scrollPane.setBorder(null);
        scrollPane.setBackground(UITheme.BG_DARK);
        scrollPane.getViewport().setBackground(UITheme.BG_DARK);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // 3. Bottom Input and Feedback Area
        mainPanel.add(createBottomPanel(), BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_CARD);
        header.setBorder(new EmptyBorder(12, 20, 12, 20));

        // Left Branding
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        brandPanel.setOpaque(false);

        JLabel logo = new JLabel("🤖");
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 2));
        textPanel.setOpaque(false);
        JLabel title = new JLabel("NexaBot AI");
        title.setFont(UITheme.FONT_SUBTITLE);
        title.setForeground(UITheme.TEXT_MAIN);

        JLabel userPill = new JLabel("Logged in as: " + currentUser.getName() + " (" + currentUser.getRole() + ")");
        userPill.setFont(UITheme.FONT_SMALL);
        userPill.setForeground(UITheme.ACCENT_CYAN);

        textPanel.add(title);
        textPanel.add(userPill);

        brandPanel.add(logo);
        brandPanel.add(textPanel);

        // Right Action Toolbar
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        toolbar.setOpaque(false);

        JButton historyBtn = UITheme.createStyledButton("📜 History", UITheme.BG_INPUT, UITheme.TEXT_MAIN);
        historyBtn.addActionListener(e -> openHistory());

        JButton analyticsBtn = UITheme.createStyledButton("📊 Analytics", UITheme.BG_INPUT, UITheme.TEXT_MAIN);
        analyticsBtn.addActionListener(e -> openAnalytics());

        // Admin Knowledge Base Manager button
        if (currentUser.canManageKnowledgeBase()) {
            JButton adminKbBtn = UITheme.createStyledButton("⚙️ Manage KB", UITheme.BG_INPUT, UITheme.ACCENT_CYAN);
            adminKbBtn.addActionListener(e -> openAdminKnowledgeManager());
            toolbar.add(adminKbBtn);
        }

        JButton clearBtn = UITheme.createStyledButton("🧹 Clear", UITheme.BG_INPUT, UITheme.TEXT_MUTED);
        clearBtn.addActionListener(e -> clearChat());

        JButton logoutBtn = UITheme.createStyledButton("🚪 Logout", UITheme.DANGER_RED, Color.WHITE);
        logoutBtn.addActionListener(e -> logout());

        toolbar.add(historyBtn);
        toolbar.add(analyticsBtn);
        toolbar.add(clearBtn);
        toolbar.add(logoutBtn);

        header.add(brandPanel, BorderLayout.WEST);
        header.add(toolbar, BorderLayout.EAST);
        return header;
    }

    private JPanel createBottomPanel() {
        JPanel bottom = new JPanel();
        bottom.setLayout(new BoxLayout(bottom, BoxLayout.Y_AXIS));
        bottom.setBackground(UITheme.BG_CARD);
        bottom.setBorder(new EmptyBorder(10, 20, 10, 20));

        // Typing / Thinking Indicator
        typingIndicator = new JLabel("🤖 NexaBot is thinking...");
        typingIndicator.setFont(UITheme.FONT_SMALL);
        typingIndicator.setForeground(UITheme.ACCENT_CYAN);
        typingIndicator.setVisible(false);
        typingIndicator.setBorder(new EmptyBorder(0, 0, 4, 0));

        // Input & Send Row
        JPanel inputRow = new JPanel(new BorderLayout(10, 0));
        inputRow.setOpaque(false);

        inputField = UITheme.createStyledTextField(40);
        inputField.putClientProperty("JTextField.placeholderText", "Ask anything about Java, OOP, JDBC, Multithreading...");
        inputField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    sendMessage();
                }
            }
        });

        sendBtn = UITheme.createStyledButton("Send ➢", UITheme.PRIMARY_BLUE, Color.WHITE);
        sendBtn.addActionListener(e -> sendMessage());

        inputRow.add(inputField, BorderLayout.CENTER);
        inputRow.add(sendBtn, BorderLayout.EAST);

        // Feedback Toolbar Row
        JPanel feedbackRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 6));
        feedbackRow.setOpaque(false);

        JLabel rateLabel = new JLabel("Rate Last Response:");
        rateLabel.setFont(UITheme.FONT_SMALL);
        rateLabel.setForeground(UITheme.TEXT_MUTED);

        helpfulBtn = UITheme.createStyledButton("👍 Helpful", UITheme.BG_INPUT, UITheme.SUCCESS_GREEN);
        helpfulBtn.setEnabled(false);
        helpfulBtn.addActionListener(e -> submitFeedback(1));

        unhelpfulBtn = UITheme.createStyledButton("👎 Not Helpful", UITheme.BG_INPUT, UITheme.DANGER_RED);
        unhelpfulBtn.setEnabled(false);
        unhelpfulBtn.addActionListener(e -> submitFeedback(0));

        feedbackStatusLabel = new JLabel(" ");
        feedbackStatusLabel.setFont(UITheme.FONT_SMALL);
        feedbackStatusLabel.setForeground(UITheme.SUCCESS_GREEN);

        feedbackRow.add(rateLabel);
        feedbackRow.add(helpfulBtn);
        feedbackRow.add(unhelpfulBtn);
        feedbackRow.add(feedbackStatusLabel);

        // Database status footer
        String dbStatus = DatabaseConnection.getInstance().getConnectionStatusMessage();
        JLabel dbStatusFooter = new JLabel("Status: " + dbStatus);
        dbStatusFooter.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        dbStatusFooter.setForeground(DatabaseConnection.getInstance().isConnected()
                ? UITheme.SUCCESS_GREEN : UITheme.WARNING_AMBER);
        dbStatusFooter.setAlignmentX(Component.CENTER_ALIGNMENT);

        bottom.add(typingIndicator);
        bottom.add(inputRow);
        bottom.add(feedbackRow);
        bottom.add(dbStatusFooter);

        return bottom;
    }

    private void initConversation() {
        // Start conversation in background worker
        SwingWorker<Conversation, Void> worker = new SwingWorker<>() {
            @Override
            protected Conversation doInBackground() throws Exception {
                return chatbotService.startNewConversation(currentUser.getUserId(), "Study Session");
            }

            @Override
            protected void done() {
                try {
                    currentConversation = get();
                    // Initial Welcome Greeting
                    appendBotBubble("Hello " + currentUser.getName() + "! Welcome to NexaBot. How can I help you with your Java, OOP, or Database studies today?",
                            "GREETING", 1.0, new Date());
                } catch (Exception e) {
                    currentConversation = new Conversation(currentUser.getUserId(), "Offline Session");
                    currentConversation.setConversationId(1);
                    appendBotBubble("Hello " + currentUser.getName() + "! (In-Memory Session) Ask me any question about Java!",
                            "GREETING", 1.0, new Date());
                }
            }
        };
        worker.execute();
    }

    private void sendMessage() {
        String text = inputField.getText();
        if (text == null || text.trim().isEmpty()) {
            return;
        }

        String userMsg = text.trim();
        inputField.setText("");
        inputField.setEnabled(false);
        sendBtn.setEnabled(false);
        typingIndicator.setVisible(true);

        // Append user bubble to UI immediately
        appendUserBubble(userMsg, new Date());

        // Process chatbot response in background thread (Multithreading requirement)
        SwingWorker<Message, Void> worker = new SwingWorker<>() {
            @Override
            protected Message doInBackground() throws Exception {
                int convId = (currentConversation != null) ? currentConversation.getConversationId() : 1;
                return chatbotService.processMessage(convId, currentUser.getUserId(), userMsg);
            }

            @Override
            protected void done() {
                typingIndicator.setVisible(false);
                inputField.setEnabled(true);
                sendBtn.setEnabled(true);
                inputField.requestFocusInWindow();

                try {
                    Message result = get();
                    lastMessageId = result.getMessageId();
                    appendBotBubble(result.getBotResponse(), result.getIntent(), result.getConfidence(), new Date());
                    helpfulBtn.setEnabled(true);
                    unhelpfulBtn.setEnabled(true);
                    feedbackStatusLabel.setText("");
                } catch (Exception e) {
                    Throwable cause = e.getCause() != null ? e.getCause() : e;
                    appendBotBubble("An error occurred: " + cause.getMessage(), "ERROR", 0.0, new Date());
                }
            }
        };
        worker.execute();
    }

    private void submitFeedback(int rating) {
        if (lastMessageId <= 0) return;
        helpfulBtn.setEnabled(false);
        unhelpfulBtn.setEnabled(false);

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws Exception {
                chatbotService.submitFeedback(lastMessageId, currentUser.getUserId(), rating,
                        rating == 1 ? "Helpful answer" : "Not helpful");
                return null;
            }

            @Override
            protected void done() {
                feedbackStatusLabel.setText(rating == 1 ? "✓ Marked as Helpful!" : "✓ Feedback recorded!");
                feedbackStatusLabel.setForeground(rating == 1 ? UITheme.SUCCESS_GREEN : UITheme.WARNING_AMBER);
            }
        };
        worker.execute();
    }

    private void appendUserBubble(String text, Date timestamp) {
        JPanel bubble = new JPanel(new BorderLayout(5, 5)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.USER_BUBBLE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.dispose();
            }
        };
        bubble.setOpaque(false);
        bubble.setBorder(new EmptyBorder(10, 14, 10, 14));
        bubble.setMaximumSize(new Dimension(550, Integer.MAX_VALUE));

        JTextArea textArea = createBubbleTextArea(text, Color.WHITE);

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        JLabel timeLabel = new JLabel("You • " + sdf.format(timestamp), SwingConstants.RIGHT);
        timeLabel.setFont(UITheme.FONT_SMALL);
        timeLabel.setForeground(new Color(224, 231, 255));

        bubble.add(textArea, BorderLayout.CENTER);
        bubble.add(timeLabel, BorderLayout.SOUTH);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 6));
        row.setOpaque(false);
        row.add(bubble);

        chatMessagesPanel.add(row);
        chatMessagesPanel.revalidate();
        scrollToBottom();
    }

    private void appendBotBubble(String text, String intent, double confidence, Date timestamp) {
        JPanel bubble = new JPanel(new BorderLayout(5, 5)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BOT_BUBBLE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.setColor(UITheme.BORDER_COLOR);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 16, 16);
                g2.dispose();
            }
        };
        bubble.setOpaque(false);
        bubble.setBorder(new EmptyBorder(10, 14, 10, 14));
        bubble.setMaximumSize(new Dimension(650, Integer.MAX_VALUE));

        JTextArea textArea = createBubbleTextArea(text, UITheme.TEXT_MAIN);

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        String confStr = String.format("%.0f%%", confidence * 100);
        JLabel metaLabel = new JLabel("🤖 NexaBot • " + intent + " (" + confStr + ") • " + sdf.format(timestamp));
        metaLabel.setFont(UITheme.FONT_SMALL);
        metaLabel.setForeground(UITheme.ACCENT_CYAN);

        bubble.add(metaLabel, BorderLayout.NORTH);
        bubble.add(textArea, BorderLayout.CENTER);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 6));
        row.setOpaque(false);
        row.add(bubble);

        chatMessagesPanel.add(row);
        chatMessagesPanel.revalidate();
        scrollToBottom();
    }

    private JTextArea createBubbleTextArea(String text, Color textColor) {
        JTextArea area = new JTextArea(text);
        area.setWrapStyleWord(true);
        area.setLineWrap(true);
        area.setOpaque(false);
        area.setEditable(false);
        area.setFocusable(false);
        area.setFont(UITheme.FONT_REGULAR);
        area.setForeground(textColor);
        area.setBorder(null);
        return area;
    }

    private void scrollToBottom() {
        SwingUtilities.invokeLater(() -> {
            JScrollBar vertical = scrollPane.getVerticalScrollBar();
            vertical.setValue(vertical.getMaximum());
        });
    }

    private void clearChat() {
        int choice = JOptionPane.showConfirmDialog(this,
                "Clear current chat view?",
                "Confirm Clear",
                JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            chatMessagesPanel.removeAll();
            chatMessagesPanel.revalidate();
            chatMessagesPanel.repaint();
            appendBotBubble("Chat cleared. What would you like to explore next?", "GREETING", 1.0, new Date());
        }
    }

    private void openHistory() {
        SwingUtilities.invokeLater(() -> new HistoryFrame(currentUser, chatbotService).setVisible(true));
    }

    private void openAnalytics() {
        SwingUtilities.invokeLater(() -> new AnalyticsFrame().setVisible(true));
    }

    private void openAdminKnowledgeManager() {
        SwingUtilities.invokeLater(() -> new AdminKnowledgeFrame().setVisible(true));
    }

    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to log out?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            authService.logout();
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame(authService).setVisible(true));
        }
    }
}
