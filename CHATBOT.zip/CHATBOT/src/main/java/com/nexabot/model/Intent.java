package com.nexabot.model;

import java.util.*;

/**
 * Model class encapsulating a chatbot Intent.
 * Demonstrates Collections: Set<String> for fast keyword lookups,
 * and List<String> for diverse responses and training questions.
 */
public class Intent {
    private String intentName;
    private Set<String> keywords;
    private List<String> exampleQuestions;
    private List<String> responses;
    private double confidenceThreshold;

    public Intent() {
        this.keywords = new HashSet<>();
        this.exampleQuestions = new ArrayList<>();
        this.responses = new ArrayList<>();
        this.confidenceThreshold = 0.40; // Default threshold
    }

    public Intent(String intentName, Set<String> keywords, List<String> exampleQuestions, List<String> responses) {
        this.intentName = intentName;
        this.keywords = keywords != null ? keywords : new HashSet<>();
        this.exampleQuestions = exampleQuestions != null ? exampleQuestions : new ArrayList<>();
        this.responses = responses != null ? responses : new ArrayList<>();
        this.confidenceThreshold = 0.40;
    }

    public String getIntentName() {
        return intentName;
    }

    public void setIntentName(String intentName) {
        this.intentName = intentName;
    }

    public Set<String> getKeywords() {
        return keywords;
    }

    public void setKeywords(Set<String> keywords) {
        this.keywords = keywords != null ? keywords : new HashSet<>();
    }

    public void addKeyword(String keyword) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            this.keywords.add(keyword.trim().toLowerCase());
        }
    }

    public List<String> getExampleQuestions() {
        return exampleQuestions;
    }

    public void setExampleQuestions(List<String> exampleQuestions) {
        this.exampleQuestions = exampleQuestions != null ? exampleQuestions : new ArrayList<>();
    }

    public void addExampleQuestion(String question) {
        if (question != null && !question.trim().isEmpty()) {
            this.exampleQuestions.add(question.trim());
        }
    }

    public List<String> getResponses() {
        return responses;
    }

    public void setResponses(List<String> responses) {
        this.responses = responses != null ? responses : new ArrayList<>();
    }

    public void addResponse(String response) {
        if (response != null && !response.trim().isEmpty()) {
            this.responses.add(response.trim());
        }
    }

    public double getConfidenceThreshold() {
        return confidenceThreshold;
    }

    public void setConfidenceThreshold(double confidenceThreshold) {
        this.confidenceThreshold = confidenceThreshold;
    }

    /**
     * Retrieves an appropriate response (randomized if multiple choices available).
     */
    public String getRandomResponse() {
        if (responses.isEmpty()) {
            return "I recognize this intent, but no response has been configured yet.";
        }
        int index = (int) (Math.random() * responses.size());
        return responses.get(index);
    }

    @Override
    public String toString() {
        return "Intent[name='" + intentName + "', keywords=" + keywords.size() + ", responses=" + responses.size() + "]";
    }
}
