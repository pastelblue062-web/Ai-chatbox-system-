package com.nexabot.gui;

import com.nexabot.dao.KnowledgeBaseDAO;
import com.nexabot.model.KnowledgeEntry;
import com.nexabot.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Admin Knowledge Base Management Frame.
 * Allows administrators to view, search, add, and remove Q&A entries in the database.
 */
public class AdminKnowledgeFrame extends JFrame {

    private final KnowledgeBaseDAO knowledgeBaseDAO;
    private JTable kbTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JTextField intentField;
    private JTextField questionField;
    private JTextField keywordsField;
    private JTextArea responseArea;
    private JLabel statusLabel;
    private List<KnowledgeEntry> currentEntries;

    public AdminKnowledgeFrame() {
        this.knowledgeBaseDAO = new KnowledgeBaseDAO();
        initUI();
        loadEntries("");
    }

    private void initUI() {
        setTitle("Admin Portal - Knowledge Base Management | NexaBot");
        setSize(950, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(UITheme.BG_DARK);
        mainPanel.setBorder(new EmptyBorder(20, 25, 20, 25));

        // Header with search bar
        JPanel header = new JPanel(new BorderLayout(10, 0));
        header.setOpaque(false);

        JLabel title = new JLabel("⚙️ Knowledge Base Administration");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_MAIN);

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchRow.setOpaque(false);
        JLabel searchLbl = new JLabel("Search:");
        searchLbl.setFont(UITheme.FONT_BOLD);
        searchLbl.setForeground(UITheme.TEXT_MUTED);

        searchField = UITheme.createStyledTextField(15);
        JButton searchBtn = UITheme.createStyledButton("Filter", UITheme.BG_INPUT, UITheme.TEXT_MAIN);
        searchBtn.addActionListener(e -> loadEntries(searchField.getText()));

        JButton resetBtn = UITheme.createStyledButton("Reset", UITheme.BG_INPUT, UITheme.TEXT_MUTED);
        resetBtn.addActionListener(e -> {
            searchField.setText("");
            loadEntries("");
        });

        searchRow.add(searchLbl);
        searchRow.add(searchField);
        searchRow.add(searchBtn);
        searchRow.add(resetBtn);

        header.add(title, BorderLayout.WEST);
        header.add(searchRow, BorderLayout.EAST);
        mainPanel.add(header, BorderLayout.NORTH);

        // Center Table
        String[] columns = {"ID", "Intent", "Sample Question", "Keywords", "Response"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        kbTable = new JTable(tableModel);
        kbTable.setBackground(UITheme.BG_CARD);
        kbTable.setForeground(UITheme.TEXT_MAIN);
        kbTable.setFont(UITheme.FONT_REGULAR);
        kbTable.setRowHeight(26);
        kbTable.getTableHeader().setFont(UITheme.FONT_BOLD);
        kbTable.getTableHeader().setBackground(UITheme.BG_INPUT);
        kbTable.getTableHeader().setForeground(UITheme.TEXT_MAIN);
        kbTable.getColumnModel().getColumn(0).setPreferredWidth(45);
        kbTable.getColumnModel().getColumn(1).setPreferredWidth(120);
        kbTable.getColumnModel().getColumn(2).setPreferredWidth(200);
        kbTable.getColumnModel().getColumn(3).setPreferredWidth(180);
        kbTable.getColumnModel().getColumn(4).setPreferredWidth(350);

        JScrollPane tableScroll = new JScrollPane(kbTable);
        tableScroll.getViewport().setBackground(UITheme.BG_CARD);
        tableScroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));

        mainPanel.add(tableScroll, BorderLayout.CENTER);

        // Bottom Form Panel (Add new entry + Delete selected)
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setOpaque(false);

        JPanel formCard = UITheme.createCardPanel();
        formCard.setLayout(new GridLayout(4, 2, 10, 8));

        intentField = UITheme.createStyledTextField(15);
        questionField = UITheme.createStyledTextField(20);
        keywordsField = UITheme.createStyledTextField(20);
        responseArea = new JTextArea(2, 20);
        responseArea.setBackground(UITheme.BG_INPUT);
        responseArea.setForeground(UITheme.TEXT_MAIN);
        responseArea.setFont(UITheme.FONT_REGULAR);
        responseArea.setLineWrap(true);
        responseArea.setWrapStyleWord(true);

        formCard.add(createFormRow("Intent Name (e.g., RECURSION):", intentField));
        formCard.add(createFormRow("Sample Question:", questionField));
        formCard.add(createFormRow("Keywords (comma separated):", keywordsField));
        formCard.add(createFormRow("Chatbot Answer:", new JScrollPane(responseArea)));

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
        actionRow.setOpaque(false);

        statusLabel = new JLabel(" ");
        statusLabel.setFont(UITheme.FONT_SMALL);
        statusLabel.setForeground(UITheme.SUCCESS_GREEN);

        JButton deleteBtn = UITheme.createStyledButton("Delete Selected", UITheme.DANGER_RED, Color.WHITE);
        deleteBtn.addActionListener(e -> deleteSelectedEntry());

        JButton addBtn = UITheme.createStyledButton("+ Add Knowledge Entry", UITheme.PRIMARY_BLUE, Color.WHITE);
        addBtn.addActionListener(e -> addNewEntry());

        actionRow.add(statusLabel);
        actionRow.add(deleteBtn);
        actionRow.add(addBtn);

        bottomPanel.add(formCard);
        bottomPanel.add(actionRow);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private JPanel createFormRow(String labelText, JComponent comp) {
        JPanel row = new JPanel(new BorderLayout(5, 2));
        row.setOpaque(false);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(UITheme.FONT_BOLD);
        lbl.setForeground(UITheme.TEXT_MAIN);
        row.add(lbl, BorderLayout.NORTH);
        row.add(comp, BorderLayout.CENTER);
        return row;
    }

    private void loadEntries(String query) {
        tableModel.setRowCount(0);
        SwingWorker<List<KnowledgeEntry>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<KnowledgeEntry> doInBackground() throws Exception {
                return (query == null || query.trim().isEmpty())
                        ? knowledgeBaseDAO.findAll()
                        : knowledgeBaseDAO.search(query.trim());
            }

            @Override
            protected void done() {
                try {
                    currentEntries = get();
                    for (KnowledgeEntry e : currentEntries) {
                        tableModel.addRow(new Object[]{
                                e.getKnowledgeId(),
                                e.getIntent(),
                                e.getQuestion(),
                                e.getKeywords(),
                                e.getResponse()
                        });
                    }
                } catch (Exception e) {
                    statusLabel.setText("Failed to load entries: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void addNewEntry() {
        String intent = intentField.getText();
        String question = questionField.getText();
        String keywords = keywordsField.getText();
        String response = responseArea.getText();

        if (intent.trim().isEmpty() || question.trim().isEmpty() || response.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in Intent, Question, and Response fields.",
                    "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        KnowledgeEntry entry = new KnowledgeEntry(
                intent.trim().toUpperCase(),
                question.trim(),
                keywords.trim(),
                response.trim()
        );

        SwingWorker<KnowledgeEntry, Void> worker = new SwingWorker<>() {
            @Override
            protected KnowledgeEntry doInBackground() throws Exception {
                return knowledgeBaseDAO.save(entry);
            }

            @Override
            protected void done() {
                try {
                    get();
                    statusLabel.setText("✓ New entry added successfully!");
                    statusLabel.setForeground(UITheme.SUCCESS_GREEN);
                    intentField.setText("");
                    questionField.setText("");
                    keywordsField.setText("");
                    responseArea.setText("");
                    loadEntries("");
                } catch (Exception e) {
                    statusLabel.setText("Error: " + e.getMessage());
                    statusLabel.setForeground(UITheme.DANGER_RED);
                }
            }
        };
        worker.execute();
    }

    private void deleteSelectedEntry() {
        int selectedRow = kbTable.getSelectedRow();
        if (selectedRow == -1 || currentEntries == null) {
            JOptionPane.showMessageDialog(this, "Please select an entry to delete.",
                    "No Selection", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int knowledgeId = (int) tableModel.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete Knowledge Entry ID #" + knowledgeId + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            SwingWorker<Void, Void> worker = new SwingWorker<>() {
                @Override
                protected Void doInBackground() throws Exception {
                    knowledgeBaseDAO.deleteById(knowledgeId);
                    return null;
                }

                @Override
                protected void done() {
                    statusLabel.setText("✓ Entry #" + knowledgeId + " deleted.");
                    loadEntries("");
                }
            };
            worker.execute();
        }
    }
}
