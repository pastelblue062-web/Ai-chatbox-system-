# NexaBot - Testing & Quality Assurance Guide

## 1. Overview
This guide documents the automated and manual test cases covering all requirements of the academic project specification.

---

## 2. Test Execution Matrix

| Test ID | Module | Test Scenario | Input / Action | Expected Result | Status |
|---|---|---|---|---|---|
| **TC-01** | Auth | Valid User Login | `admin@nexabot.ai`, `Admin@123` | Login succeeds; ChatFrame opens | ✅ PASS |
| **TC-02** | Auth | Invalid Password | `admin@nexabot.ai`, `WrongPass` | Shows "Invalid email or password" error | ✅ PASS |
| **TC-03** | Auth | Empty Fields | Empty email or password | Shows validation error banner | ✅ PASS |
| **TC-04** | Auth | Duplicate Registration | Register with existing email | Shows "Account already exists" error | ✅ PASS |
| **TC-05** | NLP | Punctuation Cleaning | `What is Java???` | Strips punctuation; detects `JAVA` intent | ✅ PASS |
| **TC-06** | NLP | Stop-word Filtering | `Can you please tell me about OOP` | Removes stop words; retains `oop` | ✅ PASS |
| **TC-07** | Bot | Intent Recognition | `What is inheritance?` | Returns inheritance definition (>80% conf) | ✅ PASS |
| **TC-08** | Bot | Fallback Handling | `random gibberish xyz123` | Triggers FallbackResponseStrategy with suggestions | ✅ PASS |
| **TC-09** | Concurrency | Non-blocking GUI | Sending long question | Shows thinking indicator; GUI remains responsive | ✅ PASS |
| **TC-10** | Database | Safe Offline Mode | MySQL offline | Operates in resilient In-Memory mode without crashing | ✅ PASS |
| **TC-11** | Feedback | Submit Rating | Click 👍 Helpful button | Feedback stored; status badge turns green | ✅ PASS |
| **TC-12** | Admin | Dynamic KB Addition | Add new Q&A in Admin portal | Immediately available in chat without restart | ✅ PASS |

---

## 3. Running Automated Tests

Run the included verification suite with either:

```cmd
test.bat
```

Or via the Java CLI:
```bash
javac -cp ".;bin;lib/mysql-connector-j-8.3.0.jar;src/main/resources" -d bin src/test/java/com/nexabot/ChatbotTestSuite.java
java -cp ".;bin;lib/mysql-connector-j-8.3.0.jar;src/main/resources" com.nexabot.ChatbotTestSuite
```

All 21 test assertions will execute and output formatted PASS indicators.
