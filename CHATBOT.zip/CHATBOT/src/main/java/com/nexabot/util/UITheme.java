package com.nexabot.util;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Modern Design System and UI Theme Constants for NexaBot Swing GUI.
 * Provides curated colors, modern typography, rounded buttons, and speech bubbles.
 */
public class UITheme {

    // Color Palette
    public static final Color BG_DARK = new Color(15, 23, 42);         // Slate 900
    public static final Color BG_CARD = new Color(30, 41, 59);         // Slate 800
    public static final Color BG_INPUT = new Color(51, 65, 85);        // Slate 700
    public static final Color PRIMARY_BLUE = new Color(59, 130, 246);  // Blue 500
    public static final Color PRIMARY_HOVER = new Color(37, 99, 235); // Blue 600
    public static final Color ACCENT_CYAN = new Color(6, 182, 212);    // Cyan 500
    public static final Color SUCCESS_GREEN = new Color(34, 197, 94);  // Green 500
    public static final Color DANGER_RED = new Color(239, 68, 68);     // Red 500
    public static final Color WARNING_AMBER = new Color(245, 158, 11); // Amber 500

    public static final Color TEXT_MAIN = new Color(248, 250, 252);    // Slate 50
    public static final Color TEXT_MUTED = new Color(148, 163, 184);   // Slate 400
    public static final Color TEXT_DARK = new Color(30, 41, 59);

    public static final Color USER_BUBBLE = new Color(37, 99, 235);    // User Blue Bubble
    public static final Color BOT_BUBBLE = new Color(51, 65, 85);      // Bot Slate Bubble
    public static final Color BORDER_COLOR = new Color(71, 85, 105);

    // Typography
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.BOLD, 15);
    public static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font FONT_CODE = new Font("Consolas", Font.PLAIN, 13);

    /**
     * Creates a styled modern button with rounded corners and hover effects.
     */
    public static JButton createStyledButton(String text, Color bgColor, Color textColor) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(bgColor.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(bgColor.brighter());
                } else {
                    g2.setColor(bgColor);
                }
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setFont(FONT_BOLD);
        button.setForeground(textColor);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(new EmptyBorder(8, 16, 8, 16));
        return button;
    }

    /**
     * Creates a styled text field with rounded padding and modern colors.
     */
    public static JTextField createStyledTextField(int columns) {
        JTextField field = new JTextField(columns);
        field.setBackground(BG_INPUT);
        field.setForeground(TEXT_MAIN);
        field.setCaretColor(TEXT_MAIN);
        field.setFont(FONT_REGULAR);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                new EmptyBorder(8, 10, 8, 10)
        ));
        return field;
    }

    /**
     * Creates a styled password field with rounded padding and modern colors.
     */
    public static JPasswordField createStyledPasswordField(int columns) {
        JPasswordField field = new JPasswordField(columns);
        field.setBackground(BG_INPUT);
        field.setForeground(TEXT_MAIN);
        field.setCaretColor(TEXT_MAIN);
        field.setFont(FONT_REGULAR);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1, true),
                new EmptyBorder(8, 10, 8, 10)
        ));
        return field;
    }

    /**
     * Creates a rounded card panel.
     */
    public static JPanel createCardPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_COLOR);
                g2.setStroke(new BasicStroke(1));
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
            }
        };
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(16, 16, 16, 16));
        return panel;
    }
}
