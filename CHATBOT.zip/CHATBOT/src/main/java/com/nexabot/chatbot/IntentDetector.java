package com.nexabot.chatbot;

import com.nexabot.model.Intent;
import java.util.*;

/**
 * Intent Detector using rule-based and keyword scoring NLP algorithms.
 * Calculates an interpretable confidence score between 0.0 and 1.0.
 */
public class IntentDetector {

    public static class DetectionResult {
        private final Intent intent;
        private final double confidence;
        private final Set<String> matchedKeywords;

        public DetectionResult(Intent intent, double confidence, Set<String> matchedKeywords) {
            this.intent = intent;
            this.confidence = confidence;
            this.matchedKeywords = matchedKeywords != null ? matchedKeywords : Collections.emptySet();
        }

        public Intent getIntent() {
            return intent;
        }

        public double getConfidence() {
            return confidence;
        }

        public Set<String> getMatchedKeywords() {
            return matchedKeywords;
        }

        public String getIntentName() {
            return intent != null ? intent.getIntentName() : "UNKNOWN";
        }
    }

    /**
     * Evaluates input tokens against all intents in the knowledge base.
     */
    public DetectionResult detectIntent(String cleanedText, Set<String> userKeywords, KnowledgeBase knowledgeBase) {
        if (userKeywords == null || userKeywords.isEmpty() || knowledgeBase == null) {
            return new DetectionResult(null, 0.0, Collections.emptySet());
        }

        Intent bestIntent = null;
        double highestScore = 0.0;
        Set<String> bestMatchedKeywords = new HashSet<>();

        for (Intent intent : knowledgeBase.getAllIntents().values()) {
            Set<String> intentKeywords = intent.getKeywords();
            Set<String> matched = new HashSet<>();

            // 1. Keyword match points
            int keywordHits = 0;
            for (String userWord : userKeywords) {
                if (intentKeywords.contains(userWord)) {
                    keywordHits++;
                    matched.add(userWord);
                } else {
                    // Substring match for compound terms (e.g. "multithreading" vs "threading")
                    for (String ik : intentKeywords) {
                        if (ik.length() >= 4 && (userWord.contains(ik) || ik.contains(userWord))) {
                            keywordHits++;
                            matched.add(userWord);
                            break;
                        }
                    }
                }
            }

            // 2. Example question similarity check (bonus points)
            double questionSimilarityBonus = 0.0;
            for (String sampleQ : intent.getExampleQuestions()) {
                String cleanSample = sampleQ.toLowerCase().replaceAll("[^a-zA-Z0-9\\s]", " ").trim();
                if (cleanedText.equals(cleanSample)) {
                    questionSimilarityBonus = 0.50; // Exact match bonus
                    break;
                } else if (cleanedText.contains(cleanSample) || cleanSample.contains(cleanedText)) {
                    questionSimilarityBonus = Math.max(questionSimilarityBonus, 0.35);
                }
            }

            // Calculate confidence score
            double baseConfidence = userKeywords.isEmpty() ? 0.0 : ((double) keywordHits / userKeywords.size());
            double totalConfidence = Math.min(1.0, (baseConfidence * 0.70) + questionSimilarityBonus);

            if (keywordHits > 0 && totalConfidence > highestScore) {
                highestScore = totalConfidence;
                bestIntent = intent;
                bestMatchedKeywords = matched;
            }
        }

        return new DetectionResult(bestIntent, highestScore, bestMatchedKeywords);
    }
}
