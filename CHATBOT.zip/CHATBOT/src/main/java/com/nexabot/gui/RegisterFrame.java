package com.nexabot.gui;

import com.nexabot.model.User;
import com.nexabot.service.AuthenticationService;
import com.nexabot.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Modern Swing Registration Frame.
 * Handles new account creation with role selection (Regular User vs Admin).
 */
public class RegisterFrame extends JFrame {

    private final AuthenticationService authService;
    private JTextField nameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JCheckBox adminCheckBox;
    private JTextField adminKeyField;
    private JPanel adminKeyPanel;
    private JLabel statusLabel;

    public RegisterFrame(AuthenticationService authService) {
        this.authService = authService;
        initUI();
    }

    private void initUI() {
        setTitle("NexaBot - AI Chatbot System | Register");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(480, 680);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(UITheme.BG_DARK);
        mainPanel.setLayout(new BorderLayout(0, 0));
        mainPanel.setBorder(new EmptyBorder(20, 30, 20, 30));

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("Create Account");
        titleLabel.setFont(UITheme.FONT_TITLE);
        titleLabel.setForeground(UITheme.TEXT_MAIN);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Join NexaBot to access academic chat assistance");
        subtitleLabel.setFont(UITheme.FONT_SMALL);
        subtitleLabel.setForeground(UITheme.TEXT_MUTED);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(titleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        headerPanel.add(subtitleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Form Card Panel
        JPanel cardPanel = UITheme.createCardPanel();
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));

        nameField = UITheme.createStyledTextField(20);
        emailField = UITheme.createStyledTextField(20);
        passwordField = UITheme.createStyledPasswordField(20);
        confirmPasswordField = UITheme.createStyledPasswordField(20);

        cardPanel.add(createFieldRow("Full Name", nameField));
        cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        cardPanel.add(createFieldRow("Email Address", emailField));
        cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        cardPanel.add(createFieldRow("Password (min 6 characters)", passwordField));
        cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        cardPanel.add(createFieldRow("Confirm Password", confirmPasswordField));
        cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // Admin Role Option
        adminCheckBox = new JCheckBox("Register with Admin Privileges");
        adminCheckBox.setFont(UITheme.FONT_SMALL);
        adminCheckBox.setForeground(UITheme.TEXT_MAIN);
        adminCheckBox.setOpaque(false);
        adminCheckBox.setFocusPainted(false);

        adminKeyField = UITheme.createStyledPasswordField(15);
        adminKeyPanel = new JPanel(new BorderLayout(5, 5));
        adminKeyPanel.setOpaque(false);
        JLabel keyLabel = new JLabel("Admin Passcode (Default: ADMIN2026):");
        keyLabel.setFont(UITheme.FONT_SMALL);
        keyLabel.setForeground(UITheme.ACCENT_CYAN);
        adminKeyPanel.add(keyLabel, BorderLayout.NORTH);
        adminKeyPanel.add(adminKeyField, BorderLayout.CENTER);
        adminKeyPanel.setVisible(false);

        adminCheckBox.addActionListener(e -> adminKeyPanel.setVisible(adminCheckBox.isSelected()));

        cardPanel.add(adminCheckBox);
        cardPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        cardPanel.add(adminKeyPanel);

        mainPanel.add(cardPanel, BorderLayout.CENTER);

        // Footer Actions
        JPanel footerPanel = new JPanel();
        footerPanel.setOpaque(false);
        footerPanel.setLayout(new BoxLayout(footerPanel, BoxLayout.Y_AXIS));
        footerPanel.setBorder(new EmptyBorder(10, 0, 0, 0));

        statusLabel = new JLabel(" ", SwingConstants.CENTER);
        statusLabel.setFont(UITheme.FONT_SMALL);
        statusLabel.setForeground(UITheme.DANGER_RED);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton registerBtn = UITheme.createStyledButton("Register Account", UITheme.PRIMARY_BLUE, Color.WHITE);
        registerBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        registerBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        registerBtn.addActionListener(e -> performRegistration());

        JButton backBtn = new JButton("← Back to Login");
        backBtn.setFont(UITheme.FONT_SMALL);
        backBtn.setForeground(UITheme.TEXT_MUTED);
        backBtn.setContentAreaFilled(false);
        backBtn.setBorderPainted(false);
        backBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        backBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backBtn.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame(authService).setVisible(true));
        });

        footerPanel.add(statusLabel);
        footerPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        footerPanel.add(registerBtn);
        footerPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        footerPanel.add(backBtn);

        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private JPanel createFieldRow(String labelText, JComponent field) {
        JPanel row = new JPanel(new BorderLayout(0, 4));
        row.setOpaque(false);
        JLabel label = new JLabel(labelText);
        label.setFont(UITheme.FONT_BOLD);
        label.setForeground(UITheme.TEXT_MAIN);
        row.add(label, BorderLayout.NORTH);
        row.add(field, BorderLayout.CENTER);
        return row;
    }

    private void performRegistration() {
        String name = nameField.getText();
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        boolean isAdmin = adminCheckBox.isSelected();

        if (!password.equals(confirmPassword)) {
            statusLabel.setText("Passwords do not match.");
            statusLabel.setForeground(UITheme.DANGER_RED);
            return;
        }

        if (isAdmin) {
            String adminKey = adminKeyField.getText();
            if (!"ADMIN2026".equals(adminKey) && !"admin".equalsIgnoreCase(adminKey)) {
                statusLabel.setText("Invalid Admin Passcode.");
                statusLabel.setForeground(UITheme.DANGER_RED);
                return;
            }
        }

        statusLabel.setText("Creating account...");
        statusLabel.setForeground(UITheme.ACCENT_CYAN);

        SwingWorker<User, Void> worker = new SwingWorker<>() {
            @Override
            protected User doInBackground() throws Exception {
                return authService.register(name, email, password, isAdmin);
            }

            @Override
            protected void done() {
                try {
                    User user = get();
                    JOptionPane.showMessageDialog(RegisterFrame.this,
                            "Registration successful! Welcome, " + user.getName() + "!",
                            "Registration Completed",
                            JOptionPane.INFORMATION_MESSAGE);

                    dispose();
                    SwingUtilities.invokeLater(() -> new ChatFrame(user, authService).setVisible(true));
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    statusLabel.setText(cause.getMessage());
                    statusLabel.setForeground(UITheme.DANGER_RED);
                }
            }
        };
        worker.execute();
    }
}
