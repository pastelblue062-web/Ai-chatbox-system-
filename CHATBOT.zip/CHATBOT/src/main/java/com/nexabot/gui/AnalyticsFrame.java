package com.nexabot.gui;

import com.nexabot.model.AnalyticsData;
import com.nexabot.service.AnalyticsService;
import com.nexabot.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Modern Swing Analytics Dashboard.
 * Displays key KPIs, feedback satisfaction, and intent frequency distribution bars.
 */
public class AnalyticsFrame extends JFrame {

    private final AnalyticsService analyticsService;
    private JPanel cardsPanel;
    private JPanel distributionPanel;
    private JLabel statusLabel;

    public AnalyticsFrame() {
        this.analyticsService = new AnalyticsService();
        initUI();
        loadAnalyticsData();
    }

    private void initUI() {
        setTitle("System Analytics Dashboard - NexaBot");
        setSize(850, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(UITheme.BG_DARK);
        mainPanel.setBorder(new EmptyBorder(20, 25, 20, 25));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("📊 NexaBot AI Analytics & Insights");
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_MAIN);

        JButton refreshBtn = UITheme.createStyledButton("↻ Refresh Metrics", UITheme.BG_INPUT, UITheme.TEXT_MAIN);
        refreshBtn.addActionListener(e -> loadAnalyticsData());

        header.add(title, BorderLayout.WEST);
        header.add(refreshBtn, BorderLayout.EAST);
        mainPanel.add(header, BorderLayout.NORTH);

        // Center Content (KPI Cards + Distribution Bar Panel)
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setOpaque(false);

        cardsPanel = new JPanel(new GridLayout(1, 4, 12, 0));
        cardsPanel.setOpaque(false);
        cardsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

        distributionPanel = UITheme.createCardPanel();
        distributionPanel.setLayout(new BoxLayout(distributionPanel, BoxLayout.Y_AXIS));

        statusLabel = new JLabel("Loading metrics...", SwingConstants.CENTER);
        statusLabel.setFont(UITheme.FONT_REGULAR);
        statusLabel.setForeground(UITheme.TEXT_MUTED);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(cardsPanel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(statusLabel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        centerPanel.add(distributionPanel);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // Footer
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setOpaque(false);
        JButton closeBtn = UITheme.createStyledButton("Close", UITheme.PRIMARY_BLUE, Color.WHITE);
        closeBtn.addActionListener(e -> dispose());
        footer.add(closeBtn);
        mainPanel.add(footer, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void loadAnalyticsData() {
        statusLabel.setText("Aggregating system statistics...");
        cardsPanel.removeAll();
        distributionPanel.removeAll();

        SwingWorker<AnalyticsData, Void> worker = new SwingWorker<>() {
            @Override
            protected AnalyticsData doInBackground() throws Exception {
                return analyticsService.getDashboardMetrics();
            }

            @Override
            protected void done() {
                try {
                    AnalyticsData data = get();
                    statusLabel.setText("");
                    renderCards(data);
                    renderDistribution(data);
                    revalidate();
                    repaint();
                } catch (Exception e) {
                    statusLabel.setText("Failed to load metrics: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void renderCards(AnalyticsData data) {
        cardsPanel.removeAll();
        cardsPanel.add(createKpiCard("Total Users", String.valueOf(data.getTotalUsers()), "👥 Active Accounts", UITheme.PRIMARY_BLUE));
        cardsPanel.add(createKpiCard("Conversations", String.valueOf(data.getTotalConversations()), "💬 Chat Sessions", UITheme.ACCENT_CYAN));
        cardsPanel.add(createKpiCard("Messages", String.valueOf(data.getTotalMessages()), "📨 Queries Handled", UITheme.SUCCESS_GREEN));

        String satisfaction = String.format("%.0f%%", data.getHelpfulPercentage());
        cardsPanel.add(createKpiCard("Helpful Ratio", satisfaction, "👍 " + data.getHelpfulCount() + " / 👎 " + data.getUnhelpfulCount(), UITheme.WARNING_AMBER));
        cardsPanel.revalidate();
    }

    private JPanel createKpiCard(String title, String mainValue, String subValue, Color accentColor) {
        JPanel card = UITheme.createCardPanel();
        card.setLayout(new GridLayout(3, 1, 0, 4));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(UITheme.FONT_SMALL);
        titleLbl.setForeground(UITheme.TEXT_MUTED);

        JLabel valLbl = new JLabel(mainValue);
        valLbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
        valLbl.setForeground(accentColor);

        JLabel subLbl = new JLabel(subValue);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        subLbl.setForeground(UITheme.TEXT_MAIN);

        card.add(titleLbl);
        card.add(valLbl);
        card.add(subLbl);
        return card;
    }

    private void renderDistribution(AnalyticsData data) {
        distributionPanel.removeAll();

        JLabel title = new JLabel("Most Common Intents & Query Distribution");
        title.setFont(UITheme.FONT_SUBTITLE);
        title.setForeground(UITheme.TEXT_MAIN);
        distributionPanel.add(title);
        distributionPanel.add(Box.createRigidArea(new Dimension(0, 12)));

        Map<String, Integer> map = data.getIntentDistribution();
        if (map.isEmpty()) {
            JLabel emptyLbl = new JLabel("No intent data recorded yet.");
            emptyLbl.setFont(UITheme.FONT_REGULAR);
            emptyLbl.setForeground(UITheme.TEXT_MUTED);
            distributionPanel.add(emptyLbl);
            return;
        }

        // Sort by frequency descending
        List<Map.Entry<String, Integer>> sorted = new ArrayList<>(map.entrySet());
        sorted.sort((a, b) -> b.getValue() - a.getValue());

        int maxCount = sorted.get(0).getValue();
        int displayLimit = Math.min(6, sorted.size());

        for (int i = 0; i < displayLimit; i++) {
            Map.Entry<String, Integer> entry = sorted.get(i);
            distributionPanel.add(createIntentBar(entry.getKey(), entry.getValue(), maxCount));
            distributionPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        }

        // Average Confidence Indicator
        JLabel avgConfLabel = new JLabel(String.format("Average AI Confidence Score: %.1f%%  •  Top Intent: %s",
                data.getAverageConfidence() * 100, data.getMostFrequentIntent()));
        avgConfLabel.setFont(UITheme.FONT_SMALL);
        avgConfLabel.setForeground(UITheme.ACCENT_CYAN);
        distributionPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        distributionPanel.add(avgConfLabel);

        distributionPanel.revalidate();
    }

    private JPanel createIntentBar(String intentName, int count, int maxCount) {
        JPanel barRow = new JPanel(new BorderLayout(10, 0));
        barRow.setOpaque(false);
        barRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));

        JLabel nameLabel = new JLabel(intentName);
        nameLabel.setFont(UITheme.FONT_BOLD);
        nameLabel.setForeground(UITheme.TEXT_MAIN);
        nameLabel.setPreferredSize(new Dimension(160, 22));

        int percentage = (maxCount > 0) ? (count * 100 / maxCount) : 0;
        JProgressBar progressBar = new JProgressBar(0, maxCount);
        progressBar.setValue(count);
        progressBar.setForeground(UITheme.PRIMARY_BLUE);
        progressBar.setBackground(UITheme.BG_INPUT);
        progressBar.setBorderPainted(false);
        progressBar.setPreferredSize(new Dimension(300, 16));

        JLabel countLabel = new JLabel(count + " hits (" + percentage + "%)");
        countLabel.setFont(UITheme.FONT_SMALL);
        countLabel.setForeground(UITheme.TEXT_MUTED);
        countLabel.setPreferredSize(new Dimension(90, 22));

        barRow.add(nameLabel, BorderLayout.WEST);
        barRow.add(progressBar, BorderLayout.CENTER);
        barRow.add(countLabel, BorderLayout.EAST);

        return barRow;
    }
}
