package com.nexabot.exception;

/**
 * Exception thrown when natural language processing or response generation fails.
 */
public class ChatbotProcessingException extends NexaBotException {

    private final String originalInput;

    public ChatbotProcessingException(String message) {
        super(message);
        this.originalInput = null;
    }

    public ChatbotProcessingException(String message, String originalInput) {
        super(message);
        this.originalInput = originalInput;
    }

    public ChatbotProcessingException(String message, Throwable cause) {
        super(message, cause);
        this.originalInput = null;
    }

    public String getOriginalInput() {
        return originalInput;
    }
}
