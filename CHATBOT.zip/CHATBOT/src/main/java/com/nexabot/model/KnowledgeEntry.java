package com.nexabot.model;

import java.sql.Timestamp;

/**
 * Model class representing an entry in the knowledge base table.
 */
public class KnowledgeEntry {
    private int knowledgeId;
    private String intent;
    private String question;
    private String keywords;
    private String response;
    private Timestamp createdAt;

    public KnowledgeEntry() {
    }

    public KnowledgeEntry(int knowledgeId, String intent, String question, String keywords, String response, Timestamp createdAt) {
        this.knowledgeId = knowledgeId;
        this.intent = intent;
        this.question = question;
        this.keywords = keywords;
        this.response = response;
        this.createdAt = createdAt;
    }

    public KnowledgeEntry(String intent, String question, String keywords, String response) {
        this.intent = intent;
        this.question = question;
        this.keywords = keywords;
        this.response = response;
    }

    public int getKnowledgeId() {
        return knowledgeId;
    }

    public void setKnowledgeId(int knowledgeId) {
        this.knowledgeId = knowledgeId;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "KnowledgeEntry[id=" + knowledgeId + ", intent='" + intent + "', q='" + question + "']";
    }
}
