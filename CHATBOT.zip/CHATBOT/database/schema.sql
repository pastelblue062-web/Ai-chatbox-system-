-- =======================================================
-- NexaBot - AI Chatbot System
-- Database Schema Definition (MySQL)
-- Database Name: nexabot_db
-- =======================================================

CREATE DATABASE IF NOT EXISTS nexabot_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE nexabot_db;

-- -------------------------------------------------------
-- Table 1: Users
-- Stores user accounts, credentials, and roles (Admin/User)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(256) NOT NULL, -- Salted SHA-256 hash
    role ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_email (email)
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Table 2: Conversations
-- Stores individual chat sessions initiated by users
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversations (
    conversation_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(150) DEFAULT 'New Conversation',
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_conversation_user (user_id)
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Table 3: Messages
-- Stores individual message exchanges with intent & confidence
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT NOT NULL,
    user_id INT NOT NULL,
    user_message TEXT NOT NULL,
    bot_response TEXT NOT NULL,
    intent VARCHAR(50) NOT NULL DEFAULT 'UNKNOWN',
    confidence DOUBLE NOT NULL DEFAULT 0.0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_message_conversation (conversation_id),
    INDEX idx_message_intent (intent)
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Table 4: Feedback
-- Stores user ratings (1 for Helpful, 0 for Not Helpful) & comments
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    message_id INT NOT NULL,
    user_id INT NOT NULL,
    rating TINYINT NOT NULL COMMENT '1 = Helpful, 0 = Unhelpful',
    comment VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (message_id) REFERENCES messages(message_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_feedback_message (message_id)
) ENGINE=InnoDB;

-- -------------------------------------------------------
-- Table 5: Knowledge Base
-- Stores customizable intents, sample questions, and canonical answers
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS knowledge_base (
    knowledge_id INT AUTO_INCREMENT PRIMARY KEY,
    intent VARCHAR(50) NOT NULL,
    question VARCHAR(255) NOT NULL,
    keywords VARCHAR(255) NOT NULL, -- Comma-separated keyword list
    response TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_kb_intent (intent)
) ENGINE=InnoDB;
