package com.nexabot.chatbot;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Natural Language Processing (NLP) text preprocessor.
 * Adheres to specification:
 *  1. Lowercase conversion
 *  2. Trimming
 *  3. Punctuation removal
 *  4. Tokenization
 *  5. Stop-word filtering
 *  6. Keyword extraction
 * Demonstrates Collections: Set<String> for O(1) stop-word filtering.
 */
public class TextProcessor {

    private static final Set<String> STOP_WORDS = new HashSet<>(Arrays.asList(
            "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are",
            "aren't", "as", "at", "be", "because", "been", "before", "being", "below", "between", "both",
            "but", "by", "can", "cannot", "could", "did", "do", "does", "doing", "down", "during", "each",
            "few", "for", "from", "further", "had", "has", "have", "having", "he", "her", "here", "hers",
            "herself", "him", "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself",
            "let's", "me", "more", "most", "my", "myself", "no", "nor", "not", "of", "off", "on", "once",
            "only", "or", "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same", "she",
            "should", "so", "some", "such", "than", "that", "the", "their", "theirs", "them", "themselves",
            "then", "there", "these", "they", "this", "those", "through", "to", "too", "under", "until",
            "up", "very", "was", "we", "were", "what", "when", "where", "which", "while", "who", "whom",
            "why", "with", "would", "you", "your", "yours", "yourself", "yourselves", "tell", "please",
            "give", "explain", "describe", "know", "want"
    ));

    private static final Pattern PUNCTUATION_PATTERN = Pattern.compile("[^a-zA-Z0-9\\s]");
    private static final Pattern MULTIPLE_SPACES_PATTERN = Pattern.compile("\\s+");

    /**
     * Cleans and normalizes the raw input text.
     */
    public String cleanText(String input) {
        if (input == null) return "";
        String text = input.trim().toLowerCase();
        text = PUNCTUATION_PATTERN.matcher(text).replaceAll(" ");
        text = MULTIPLE_SPACES_PATTERN.matcher(text).replaceAll(" ");
        return text.trim();
    }

    /**
     * Splits text into individual word tokens.
     */
    public List<String> tokenize(String cleanedText) {
        if (cleanedText == null || cleanedText.isEmpty()) {
            return Collections.emptyList();
        }
        String[] parts = cleanedText.split("\\s+");
        List<String> tokens = new ArrayList<>(parts.length);
        for (String p : parts) {
            if (!p.isEmpty()) {
                tokens.add(p);
            }
        }
        return tokens;
    }

    /**
     * Filters out common English stop words while retaining meaningful programming keywords.
     */
    public Set<String> extractKeywords(List<String> tokens) {
        Set<String> keywords = new LinkedHashSet<>();
        for (String token : tokens) {
            String lower = token.toLowerCase();
            // Preserve domain-critical short words like "db", "ui", "io"
            if (!STOP_WORDS.contains(lower) || isProgrammingKeyword(lower)) {
                keywords.add(lower);
            }
        }
        // If everything was filtered out, preserve original tokens
        if (keywords.isEmpty() && !tokens.isEmpty()) {
            keywords.addAll(tokens);
        }
        return keywords;
    }

    private boolean isProgrammingKeyword(String word) {
        return word.equals("oop") || word.equals("jdbc") || word.equals("sql")
                || word.equals("jvm") || word.equals("jdk") || word.equals("api");
    }
}
