package com.nexabot.util;

import com.nexabot.exception.InvalidInputException;
import java.util.regex.Pattern;

/**
 * Utility class for validating user input fields across the application.
 */
public class ValidationUtil {

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$"
    );

    public static void validateName(String name) throws InvalidInputException {
        if (name == null || name.trim().isEmpty()) {
            throw new InvalidInputException("Name", "Name cannot be empty.");
        }
        if (name.trim().length() < 2) {
            throw new InvalidInputException("Name", "Name must be at least 2 characters long.");
        }
        if (name.length() > 80) {
            throw new InvalidInputException("Name", "Name cannot exceed 80 characters.");
        }
    }

    public static void validateEmail(String email) throws InvalidInputException {
        if (email == null || email.trim().isEmpty()) {
            throw new InvalidInputException("Email", "Email address cannot be empty.");
        }
        if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new InvalidInputException("Email", "Please enter a valid email address (e.g., student@university.edu).");
        }
    }

    public static void validatePassword(String password) throws InvalidInputException {
        if (password == null || password.isEmpty()) {
            throw new InvalidInputException("Password", "Password cannot be empty.");
        }
        if (password.length() < 6) {
            throw new InvalidInputException("Password", "Password must be at least 6 characters long.");
        }
    }

    public static void validateChatMessage(String message) throws InvalidInputException {
        if (message == null || message.trim().isEmpty()) {
            throw new InvalidInputException("Message", "Chat message cannot be empty.");
        }
        if (message.trim().length() > 1000) {
            throw new InvalidInputException("Message", "Message exceeds 1000 characters limit.");
        }
    }

    public static void validateFeedbackRating(int rating) throws InvalidInputException {
        if (rating != 0 && rating != 1) {
            throw new InvalidInputException("Rating", "Feedback rating must be 1 (Helpful) or 0 (Unhelpful).");
        }
    }
}
