package com.nexabot.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Utility class for hashing and verifying passwords using SHA-256 with salt.
 */
public class PasswordUtil {

    private static final SecureRandom RANDOM = new SecureRandom();

    /**
     * Hashes a plaintext password with a randomly generated salt.
     * Output format: <salt_hex>:<hash_hex>
     */
    public static String hashPassword(String plainPassword) {
        if (plainPassword == null) {
            throw new IllegalArgumentException("Password cannot be null");
        }
        byte[] salt = new byte[8];
        RANDOM.nextBytes(salt);
        String saltHex = bytesToHex(salt);
        String hashHex = computeSha256(saltHex + plainPassword);
        return saltHex + ":" + hashHex;
    }

    /**
     * Verifies if a plaintext password matches the stored salted hash.
     */
    public static boolean verifyPassword(String plainPassword, String storedHash) {
        if (plainPassword == null || storedHash == null) {
            return false;
        }

        // Check if stored in salt:hash format
        if (storedHash.contains(":")) {
            String[] parts = storedHash.split(":", 2);
            String saltHex = parts[0];
            String expectedHash = parts[1];
            String computedHash = computeSha256(saltHex + plainPassword);
            return computedHash.equalsIgnoreCase(expectedHash);
        }

        // Direct fallback for simple comparisons if needed
        return plainPassword.equals(storedHash);
    }

    private static String computeSha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
