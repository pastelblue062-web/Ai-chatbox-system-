package com.nexabot.strategy;

import com.nexabot.chatbot.IntentDetector;
import com.nexabot.chatbot.KnowledgeBase;
import com.nexabot.model.ChatResponse;
import com.nexabot.model.Intent;

import java.util.Set;

/**
 * Strategy that matches user tokens against keyword indices and knowledge base entries.
 * Demonstrates Polymorphism (implements ResponseStrategy).
 */
public class KeywordResponseStrategy implements ResponseStrategy {

    private final IntentDetector detector = new IntentDetector();

    @Override
    public boolean canHandle(Set<String> tokens, KnowledgeBase knowledgeBase) {
        if (tokens == null || tokens.isEmpty()) return false;
        IntentDetector.DetectionResult result = detector.detectIntent("", tokens, knowledgeBase);
        return result.getConfidence() >= 0.35 && result.getIntent() != null;
    }

    @Override
    public ChatResponse generateResponse(String rawInput, String cleanedInput, Set<String> tokens, KnowledgeBase knowledgeBase) {
        long start = System.currentTimeMillis();
        IntentDetector.DetectionResult result = detector.detectIntent(cleanedInput, tokens, knowledgeBase);

        Intent intent = result.getIntent();
        String responseText = (intent != null) ? intent.getRandomResponse() : "No response found.";
        String intentName = (intent != null) ? intent.getIntentName() : "UNKNOWN";
        double confidence = result.getConfidence();

        ChatResponse response = new ChatResponse(responseText, intentName, confidence, getStrategyName());
        response.setResponseTimeMs(System.currentTimeMillis() - start);
        return response;
    }

    @Override
    public String getStrategyName() {
        return "KeywordResponseStrategy";
    }
}
