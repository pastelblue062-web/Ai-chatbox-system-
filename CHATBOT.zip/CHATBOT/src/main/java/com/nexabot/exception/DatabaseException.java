package com.nexabot.exception;

/**
 * Exception thrown when database operations encounter errors
 * (e.g., connection failure, SQL syntax errors, constraint violations).
 */
public class DatabaseException extends NexaBotException {

    private final String sqlState;
    private final int errorCode;

    public DatabaseException(String message) {
        super(message);
        this.sqlState = null;
        this.errorCode = 0;
    }

    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
        this.sqlState = null;
        this.errorCode = 0;
    }

    public DatabaseException(String message, String sqlState, int errorCode, Throwable cause) {
        super(message, cause);
        this.sqlState = sqlState;
        this.errorCode = errorCode;
    }

    public String getSqlState() {
        return sqlState;
    }

    public int getErrorCode() {
        return errorCode;
    }
}
