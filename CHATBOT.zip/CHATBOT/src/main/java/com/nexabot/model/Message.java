package com.nexabot.model;

import java.sql.Timestamp;

/**
 * Model class encapsulating an individual conversation message pair.
 */
public class Message {
    private int messageId;
    private int conversationId;
    private int userId;
    private String userMessage;
    private String botResponse;
    private String intent;
    private double confidence;
    private Timestamp createdAt;

    public Message() {
    }

    public Message(int messageId, int conversationId, int userId, String userMessage,
                   String botResponse, String intent, double confidence, Timestamp createdAt) {
        this.messageId = messageId;
        this.conversationId = conversationId;
        this.userId = userId;
        this.userMessage = userMessage;
        this.botResponse = botResponse;
        this.intent = intent;
        this.confidence = confidence;
        this.createdAt = createdAt;
    }

    public Message(int conversationId, int userId, String userMessage,
                   String botResponse, String intent, double confidence) {
        this.conversationId = conversationId;
        this.userId = userId;
        this.userMessage = userMessage;
        this.botResponse = botResponse;
        this.intent = intent;
        this.confidence = confidence;
    }

    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public int getConversationId() {
        return conversationId;
    }

    public void setConversationId(int conversationId) {
        this.conversationId = conversationId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserMessage() {
        return userMessage;
    }

    public void setUserMessage(String userMessage) {
        this.userMessage = userMessage;
    }

    public String getBotResponse() {
        return botResponse;
    }

    public void setBotResponse(String botResponse) {
        this.botResponse = botResponse;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "Message[id=" + messageId + ", intent='" + intent + "', conf=" + confidence + "]";
    }
}
