package com.nexabot.model;

import java.sql.Timestamp;

/**
 * Concrete model class representing a standard user/student.
 * Inherits from User (Inheritance).
 */
public class RegularUser extends User {

    public RegularUser() {
        super();
    }

    public RegularUser(int userId, String name, String email, String password, Timestamp createdAt) {
        super(userId, name, email, password, createdAt);
    }

    public RegularUser(String name, String email, String password) {
        super(name, email, password);
    }

    @Override
    public String getRole() {
        return "USER";
    }

    @Override
    public boolean canManageKnowledgeBase() {
        return false;
    }

    @Override
    public boolean canViewAllAnalytics() {
        return false;
    }
}
