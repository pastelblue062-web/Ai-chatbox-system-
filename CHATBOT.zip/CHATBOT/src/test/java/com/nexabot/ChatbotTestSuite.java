package com.nexabot;

import com.nexabot.chatbot.KnowledgeBase;
import com.nexabot.chatbot.ResponseEngine;
import com.nexabot.chatbot.TextProcessor;
import com.nexabot.concurrent.SharedMetricsMonitor;
import com.nexabot.exception.InvalidInputException;
import com.nexabot.model.ChatResponse;
import com.nexabot.model.User;
import com.nexabot.model.Admin;
import com.nexabot.model.RegularUser;
import com.nexabot.util.PasswordUtil;
import com.nexabot.util.ValidationUtil;

import java.util.List;
import java.util.Set;

/**
 * Self-contained Automated Test Suite for NexaBot.
 * Can be run directly from IDE or command line without external test dependencies.
 */
public class ChatbotTestSuite {

    private static int testsRun = 0;
    private static int testsPassed = 0;

    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("  Running NexaBot Automated Verification Suite   ");
        System.out.println("=================================================");

        testTextProcessor();
        testPasswordHashing();
        testValidation();
        testOopHierarchy();
        testResponseEngine();
        testConcurrentMetrics();

        System.out.println("-------------------------------------------------");
        System.out.printf("Test Results: %d / %d Tests Passed.\n", testsPassed, testsRun);
        if (testsPassed == testsRun) {
            System.out.println(">>> ALL TESTS PASSED SUCCESSFULLY! <<<");
        } else {
            System.err.println(">>> SOME TESTS FAILED! <<<");
            System.exit(1);
        }
    }

    private static void assertTrue(String testName, boolean condition) {
        testsRun++;
        if (condition) {
            testsPassed++;
            System.out.println("  [PASS] " + testName);
        } else {
            System.err.println("  [FAIL] " + testName);
        }
    }

    private static void testTextProcessor() {
        System.out.println("\n--- Testing NLP TextProcessor ---");
        TextProcessor processor = new TextProcessor();

        String raw = "Can you PLEASE tell me, what is Java???";
        String cleaned = processor.cleanText(raw);
        assertTrue("Text cleaning removes punctuation & converts lowercase",
                cleaned.equals("can you please tell me what is java"));

        List<String> tokens = processor.tokenize(cleaned);
        assertTrue("Tokenization produces correct word count", tokens.size() == 8);

        Set<String> keywords = processor.extractKeywords(tokens);
        assertTrue("Stop-words filtered while 'java' preserved", keywords.contains("java") && !keywords.contains("please"));
    }

    private static void testPasswordHashing() {
        System.out.println("\n--- Testing Security & Password Hashing ---");
        String plain = "Secret@2026";
        String hash = PasswordUtil.hashPassword(plain);

        assertTrue("Hash contains salt separator ':'", hash.contains(":"));
        assertTrue("Verification succeeds with correct password", PasswordUtil.verifyPassword(plain, hash));
        assertTrue("Verification fails with incorrect password", !PasswordUtil.verifyPassword("WrongPass", hash));
    }

    private static void testValidation() {
        System.out.println("\n--- Testing Validation Rules ---");
        try {
            ValidationUtil.validateEmail("valid.student@university.edu");
            assertTrue("Valid email accepted", true);
        } catch (InvalidInputException e) {
            assertTrue("Valid email accepted", false);
        }

        try {
            ValidationUtil.validateEmail("invalid-email-format");
            assertTrue("Malformed email rejected", false);
        } catch (InvalidInputException e) {
            assertTrue("Malformed email rejected", true);
        }

        try {
            ValidationUtil.validateChatMessage("   ");
            assertTrue("Empty chat message rejected", false);
        } catch (InvalidInputException e) {
            assertTrue("Empty chat message rejected", true);
        }
    }

    private static void testOopHierarchy() {
        System.out.println("\n--- Testing OOP Hierarchy & Polymorphism ---");
        User regular = new RegularUser("Arifa", "arifa@test.com", "hash");
        User admin = new Admin("Admin", "admin@test.com", "hash");

        assertTrue("RegularUser role equals 'USER'", "USER".equals(regular.getRole()));
        assertTrue("RegularUser cannot manage KB", !regular.canManageKnowledgeBase());
        assertTrue("Admin role equals 'ADMIN'", "ADMIN".equals(admin.getRole()));
        assertTrue("Admin can manage KB", admin.canManageKnowledgeBase());
    }

    private static void testResponseEngine() {
        System.out.println("\n--- Testing Response Engine & Knowledge Base ---");
        KnowledgeBase kb = new KnowledgeBase();
        ResponseEngine engine = new ResponseEngine(kb);

        ChatResponse greeting = engine.process("Hello there!");
        assertTrue("Greeting matches GREETING intent", "GREETING".equals(greeting.getIntent()));
        assertTrue("Greeting has high confidence", greeting.getConfidence() >= 0.80);

        ChatResponse javaResp = engine.process("What is Java?");
        assertTrue("Java query matches JAVA intent", "JAVA".equals(javaResp.getIntent()));
        assertTrue("Java query has confidence > 0.5", javaResp.getConfidence() > 0.50);

        ChatResponse oopResp = engine.process("Explain OOP principles");
        assertTrue("OOP query matches OOP intent", "OOP".equals(oopResp.getIntent()));

        ChatResponse unknownResp = engine.process("quantum entanglement astrophysics 9999");
        assertTrue("Unrecognized input triggers FallbackResponseStrategy",
                "UNKNOWN".equals(unknownResp.getIntent()) || unknownResp.getStrategyUsed().contains("Fallback"));
    }

    private static void testConcurrentMetrics() {
        System.out.println("\n--- Testing Thread Safety & Synchronization ---");
        SharedMetricsMonitor monitor = SharedMetricsMonitor.getInstance();
        int initialCount = monitor.getTotalMessagesProcessed();

        monitor.recordMessageExchange("JAVA", 45);
        monitor.recordMessageExchange("OOP", 30);

        assertTrue("Total messages counter increments correctly",
                monitor.getTotalMessagesProcessed() == initialCount + 2);
        assertTrue("Intent frequency snapshot contains JAVA",
                monitor.getIntentFrequencySnapshot().containsKey("JAVA"));
    }
}
