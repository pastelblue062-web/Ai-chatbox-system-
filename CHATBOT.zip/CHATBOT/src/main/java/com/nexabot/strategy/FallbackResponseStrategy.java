package com.nexabot.strategy;

import com.nexabot.chatbot.KnowledgeBase;
import com.nexabot.model.ChatResponse;

import java.util.Arrays;
import java.util.Set;

/**
 * Fallback response strategy invoked when confidence is below acceptable threshold.
 * Demonstrates Polymorphism (implements ResponseStrategy).
 */
public class FallbackResponseStrategy implements ResponseStrategy {

    private static final String[] FALLBACK_MESSAGES = {
            "I'm not completely sure about that yet. Could you rephrase your question?",
            "I don't have enough information on that topic yet. Try asking about Java, OOP, JDBC, or Multithreading!",
            "I'm still learning! Could you try phrasing your question differently or ask for 'help'?",
            "That query doesn't match my current knowledge base. Ask me about concepts like Inheritance, Polymorphism, or Collections!"
    };

    @Override
    public boolean canHandle(Set<String> tokens, KnowledgeBase knowledgeBase) {
        // Fallback is always eligible as default safety net
        return true;
    }

    @Override
    public ChatResponse generateResponse(String rawInput, String cleanedInput, Set<String> tokens, KnowledgeBase knowledgeBase) {
        long start = System.currentTimeMillis();
        int randomIndex = (int) (Math.random() * FALLBACK_MESSAGES.length);
        String message = FALLBACK_MESSAGES[randomIndex];

        ChatResponse response = new ChatResponse(message, "UNKNOWN", 0.15, getStrategyName());
        response.setResponseTimeMs(System.currentTimeMillis() - start);

        response.setSuggestions(Arrays.asList(
                "What is OOP?",
                "What is Inheritance?",
                "What is JDBC?",
                "Explain Multithreading in Java"
        ));

        return response;
    }

    @Override
    public String getStrategyName() {
        return "FallbackResponseStrategy";
    }
}
