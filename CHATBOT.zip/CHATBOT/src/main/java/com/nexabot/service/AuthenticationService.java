package com.nexabot.service;

import com.nexabot.exception.AuthenticationException;
import com.nexabot.exception.DatabaseException;
import com.nexabot.exception.InvalidInputException;
import com.nexabot.model.User;

/**
 * Service interface defining user authentication, session, and registration contracts.
 */
public interface AuthenticationService {

    User login(String email, String password) throws AuthenticationException, DatabaseException;

    User register(String name, String email, String password, boolean isAdmin)
            throws InvalidInputException, AuthenticationException, DatabaseException;

    User getCurrentUser();

    void logout();
}
