# NexaBot - Database Design Specification

## 1. Database Overview

- **Database Engine**: MySQL (InnoDB Engine)
- **Database Name**: `nexabot_db`
- **Character Set**: `utf8mb4`
- **Collation**: `utf8mb4_unicode_ci`

---

## 2. Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    USERS ||--o{ CONVERSATIONS : starts
    USERS ||--o{ MESSAGES : sends
    USERS ||--o{ FEEDBACK : gives
    CONVERSATIONS ||--|{ MESSAGES : contains
    MESSAGES ||--o{ FEEDBACK : receives
    
    USERS {
        int user_id PK
        varchar name
        varchar email UK
        varchar password
        enum role
        timestamp created_at
    }
    
    CONVERSATIONS {
        int conversation_id PK
        int user_id FK
        varchar title
        timestamp started_at
    }
    
    MESSAGES {
        int message_id PK
        int conversation_id FK
        int user_id FK
        text user_message
        text bot_response
        varchar intent
        double confidence
        timestamp created_at
    }
    
    FEEDBACK {
        int feedback_id PK
        int message_id FK
        int user_id FK
        tinyint rating
        varchar comment
        timestamp created_at
    }
    
    KNOWLEDGE_BASE {
        int knowledge_id PK
        varchar intent
        varchar question
        varchar keywords
        text response
        timestamp created_at
    }
```

---

## 3. Table Schemas

### 3.1 Table: `users`
Stores registered user accounts and credentials.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `user_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique user identifier |
| `name` | VARCHAR(100) | NOT NULL | User's full name |
| `email` | VARCHAR(120) | NOT NULL, UNIQUE, INDEX | Unique login email |
| `password` | VARCHAR(256) | NOT NULL | Salted SHA-256 password hash (`salt:hex`) |
| `role` | ENUM('USER','ADMIN') | NOT NULL, DEFAULT 'USER' | Role-based authorization |
| `created_at`| TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Account creation date |

### 3.2 Table: `conversations`
Tracks chat sessions created by users.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `conversation_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique session identifier |
| `user_id` | INT | NOT NULL, FOREIGN KEY (users.user_id) | User who initiated session |
| `title` | VARCHAR(150) | DEFAULT 'New Conversation' | Session title |
| `started_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Timestamp session began |

### 3.3 Table: `messages`
Stores individual conversation exchanges, detected intents, and confidence ratings.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `message_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique message identifier |
| `conversation_id` | INT | NOT NULL, FOREIGN KEY (conversations.conversation_id) | Parent conversation |
| `user_id` | INT | NOT NULL, FOREIGN KEY (users.user_id) | Sender user ID |
| `user_message` | TEXT | NOT NULL | Cleaned user input |
| `bot_response` | TEXT | NOT NULL | Bot answer text |
| `intent` | VARCHAR(50) | NOT NULL, INDEX | Detected intent category |
| `confidence` | DOUBLE | NOT NULL, DEFAULT 0.0 | Confidence score (0.00 to 1.00) |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Timestamp of message |

### 3.4 Table: `feedback`
Captures user satisfaction ratings and optional comments.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `feedback_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Unique feedback identifier |
| `message_id` | INT | NOT NULL, FOREIGN KEY (messages.message_id) | Target message |
| `user_id` | INT | NOT NULL, FOREIGN KEY (users.user_id) | User who rated |
| `rating` | TINYINT | NOT NULL | 1 = Helpful, 0 = Not Helpful |
| `comment` | VARCHAR(255) | DEFAULT NULL | Optional user feedback comment |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Rating timestamp |

### 3.5 Table: `knowledge_base`
Stores dynamic intents, question variations, and responses managed by administrators.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `knowledge_id` | INT | PRIMARY KEY, AUTO_INCREMENT | Knowledge entry ID |
| `intent` | VARCHAR(50) | NOT NULL, INDEX | Intent identifier |
| `question` | VARCHAR(255) | NOT NULL | Sample training question |
| `keywords` | VARCHAR(255) | NOT NULL | Comma-separated keyword list |
| `response` | TEXT | NOT NULL | Canonical bot answer |
| `created_at` | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Creation timestamp |
