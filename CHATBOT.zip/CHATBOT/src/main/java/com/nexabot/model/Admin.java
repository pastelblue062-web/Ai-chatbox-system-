package com.nexabot.model;

import java.sql.Timestamp;

/**
 * Concrete model class representing an Administrator.
 * Inherits from User (Inheritance) with elevated privileges.
 */
public class Admin extends User {

    private String adminBadge;

    public Admin() {
        super();
        this.adminBadge = "SYSTEM_ADMIN";
    }

    public Admin(int userId, String name, String email, String password, Timestamp createdAt) {
        super(userId, name, email, password, createdAt);
        this.adminBadge = "SYSTEM_ADMIN";
    }

    public Admin(String name, String email, String password) {
        super(name, email, password);
        this.adminBadge = "SYSTEM_ADMIN";
    }

    @Override
    public String getRole() {
        return "ADMIN";
    }

    @Override
    public boolean canManageKnowledgeBase() {
        return true;
    }

    @Override
    public boolean canViewAllAnalytics() {
        return true;
    }

    public String getAdminBadge() {
        return adminBadge;
    }

    public void setAdminBadge(String adminBadge) {
        this.adminBadge = adminBadge;
    }
}
