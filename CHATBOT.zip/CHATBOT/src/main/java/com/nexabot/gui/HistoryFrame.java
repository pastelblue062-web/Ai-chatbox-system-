package com.nexabot.gui;

import com.nexabot.chatbot.ChatbotService;
import com.nexabot.model.Conversation;
import com.nexabot.model.Message;
import com.nexabot.model.User;
import com.nexabot.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Modern Swing History Frame.
 * Displays past conversations and permits viewing complete message exchanges.
 */
public class HistoryFrame extends JFrame {

    private final User currentUser;
    private final ChatbotService chatbotService;
    private JTable conversationTable;
    private DefaultTableModel tableModel;
    private JTextArea messagePreviewArea;
    private List<Conversation> cachedConversations;

    public HistoryFrame(User currentUser, ChatbotService chatbotService) {
        this.currentUser = currentUser;
        this.chatbotService = chatbotService;
        initUI();
        loadConversations();
    }

    private void initUI() {
        setTitle("Conversation History - NexaBot");
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(UITheme.BG_DARK);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        JLabel title = new JLabel("Past Conversations for " + currentUser.getName());
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_MAIN);

        JButton refreshBtn = UITheme.createStyledButton("↻ Refresh", UITheme.BG_INPUT, UITheme.TEXT_MAIN);
        refreshBtn.addActionListener(e -> loadConversations());

        headerPanel.add(title, BorderLayout.WEST);
        headerPanel.add(refreshBtn, BorderLayout.EAST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Center Split (Left Table, Right Message Detail Preview)
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(360);
        splitPane.setBackground(UITheme.BG_DARK);
        splitPane.setBorder(null);

        // Table
        String[] columns = {"ID", "Session Title", "Date"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        conversationTable = new JTable(tableModel);
        conversationTable.setBackground(UITheme.BG_CARD);
        conversationTable.setForeground(UITheme.TEXT_MAIN);
        conversationTable.setFont(UITheme.FONT_REGULAR);
        conversationTable.setRowHeight(28);
        conversationTable.getTableHeader().setFont(UITheme.FONT_BOLD);
        conversationTable.getTableHeader().setBackground(UITheme.BG_INPUT);
        conversationTable.getTableHeader().setForeground(UITheme.TEXT_MAIN);
        conversationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        conversationTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = conversationTable.getSelectedRow();
                if (selectedRow != -1 && cachedConversations != null && selectedRow < cachedConversations.size()) {
                    loadMessagesForConversation(cachedConversations.get(selectedRow).getConversationId());
                }
            }
        });

        JScrollPane tableScroll = new JScrollPane(conversationTable);
        tableScroll.getViewport().setBackground(UITheme.BG_CARD);
        tableScroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));

        // Detail View Panel
        JPanel detailPanel = new JPanel(new BorderLayout(5, 5));
        detailPanel.setBackground(UITheme.BG_CARD);
        detailPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel previewTitle = new JLabel("Conversation Exchange Details");
        previewTitle.setFont(UITheme.FONT_BOLD);
        previewTitle.setForeground(UITheme.ACCENT_CYAN);
        detailPanel.add(previewTitle, BorderLayout.NORTH);

        messagePreviewArea = new JTextArea();
        messagePreviewArea.setBackground(UITheme.BG_INPUT);
        messagePreviewArea.setForeground(UITheme.TEXT_MAIN);
        messagePreviewArea.setFont(UITheme.FONT_REGULAR);
        messagePreviewArea.setEditable(false);
        messagePreviewArea.setLineWrap(true);
        messagePreviewArea.setWrapStyleWord(true);
        messagePreviewArea.setBorder(new EmptyBorder(10, 10, 10, 10));

        JScrollPane previewScroll = new JScrollPane(messagePreviewArea);
        previewScroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_COLOR));
        detailPanel.add(previewScroll, BorderLayout.CENTER);

        splitPane.setLeftComponent(tableScroll);
        splitPane.setRightComponent(detailPanel);

        mainPanel.add(splitPane, BorderLayout.CENTER);

        // Footer Close Button
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setOpaque(false);
        JButton closeBtn = UITheme.createStyledButton("Close", UITheme.PRIMARY_BLUE, Color.WHITE);
        closeBtn.addActionListener(e -> dispose());
        footer.add(closeBtn);
        mainPanel.add(footer, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void loadConversations() {
        tableModel.setRowCount(0);
        messagePreviewArea.setText("Loading conversations...");

        SwingWorker<List<Conversation>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Conversation> doInBackground() throws Exception {
                return chatbotService.getUserConversations(currentUser.getUserId());
            }

            @Override
            protected void done() {
                try {
                    cachedConversations = get();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                    for (Conversation c : cachedConversations) {
                        String dateStr = c.getStartedAt() != null ? sdf.format(c.getStartedAt()) : "Recent";
                        tableModel.addRow(new Object[]{c.getConversationId(), c.getTitle(), dateStr});
                    }

                    if (cachedConversations.isEmpty()) {
                        messagePreviewArea.setText("No conversations recorded yet. Start chatting to view history!");
                    } else {
                        conversationTable.setRowSelectionInterval(0, 0);
                    }
                } catch (Exception e) {
                    messagePreviewArea.setText("Failed to load history: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }

    private void loadMessagesForConversation(int convId) {
        messagePreviewArea.setText("Loading messages...");

        SwingWorker<List<Message>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<Message> doInBackground() throws Exception {
                return chatbotService.getConversationMessages(convId);
            }

            @Override
            protected void done() {
                try {
                    List<Message> messages = get();
                    if (messages.isEmpty()) {
                        messagePreviewArea.setText("This conversation has no recorded messages.");
                        return;
                    }

                    StringBuilder sb = new StringBuilder();
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

                    for (Message m : messages) {
                        String timeStr = m.getCreatedAt() != null ? sdf.format(m.getCreatedAt()) : "";
                        sb.append("────────────────────────────────────────\n");
                        sb.append("👤 YOU [").append(timeStr).append("]:\n");
                        sb.append(m.getUserMessage()).append("\n\n");
                        sb.append("🤖 NEXABOT (Intent: ").append(m.getIntent())
                                .append(", Conf: ").append(String.format("%.0f%%", m.getConfidence() * 100))
                                .append("):\n");
                        sb.append(m.getBotResponse()).append("\n");
                    }
                    messagePreviewArea.setText(sb.toString());
                    messagePreviewArea.setCaretPosition(0);
                } catch (Exception e) {
                    messagePreviewArea.setText("Failed to load messages: " + e.getMessage());
                }
            }
        };
        worker.execute();
    }
}
