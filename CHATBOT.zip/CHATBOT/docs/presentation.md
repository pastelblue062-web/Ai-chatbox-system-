# NexaBot - Presentation Slides (Academic Defense)

---

## Slide 1: Title Slide
# NexaBot - AI Chatbot System
### Complete Java GUI + MySQL + NLP Desktop Application
**Course:** Object-Oriented Programming & Software Engineering Laboratory  
**Project Team:**
1. **Arifa Firdous**
2. **Muskan Pandey**
3. **Rajvardhan Singh Parmar**

---

## Slide 2: Problem Statement
- Students and software developers frequently seek rapid answers to core computer science, Java, and database questions.
- Traditional textbook indexes and documentation navigation can be tedious for quick reference.
- Existing commercial AI APIs require paid subscriptions, recurring cloud fees, and active internet connectivity.
- **The Need:** A dedicated, lightweight, offline-capable desktop chatbot combining NLP, clean OOP architecture, and persistent database tracking.

---

## Slide 3: Project Objectives
1. Build a **professional desktop chatbot** in **Java Swing**.
2. Implement **Natural Language Processing (NLP)** text preprocessing without paid external APIs.
3. Establish an **extensible rule-based Intent System** with confidence scoring.
4. Integrate **MySQL via JDBC** using the Data Access Object (DAO) pattern.
5. Maximize academic rubric points through authentic implementations of:
   - Object-Oriented Programming (Encapsulation, Inheritance, Polymorphism, Interfaces)
   - Collections & Generics (`Repository<T, ID>`, `Map<String, Intent>`, `Set<String>`)
   - Multithreading (`ExecutorService`, `SwingWorker`) and Synchronization (`synchronized` monitor).

---

## Slide 4: Proposed Solution
**NexaBot AI Chatbot System:**
- **Intuitive GUI**: Modern card layout, speech bubbles, timestamping, and quick action bars.
- **Rule-Based NLP Engine**: Multi-stage cleaning, tokenization, stop-word filtering, and keyword scoring.
- **User Authentication**: Role-based access control (Admin vs Regular User) with salted SHA-256 password hashing.
- **Conversational Feedback**: 👍 Helpful / 👎 Not Helpful rating system persisted to MySQL.
- **Analytics Dashboard**: Aggregated user counts, message volume, satisfaction percentages, and top intent frequency graphs.

---

## Slide 5: System Architecture
```
┌──────────────────────────────────────────────┐
│            Java Swing Desktop GUI            │
│  (LoginFrame, RegisterFrame, ChatFrame)      │
└──────────────────────┬───────────────────────┘
                       │
┌──────────────────────▼───────────────────────┐
│               Service Layer                  │
│ (ChatbotService, AuthenticationService, ...) │
└──────────┬───────────────────────┬───────────┘
           │                       │
┌──────────▼───────────┐ ┌─────────▼───────────┐
│   NLP Chatbot Core   │ │   DAO Data Access   │
│ - TextProcessor      │ │ - Generic Repo<T>   │
│ - IntentDetector     │ │ - UserDAO, etc.     │
│ - ResponseEngine     │ └─────────┬───────────┘
└──────────────────────┘           │
                         ┌─────────▼───────────┐
                         │   JDBC Connection   │
                         └─────────┬───────────┘
                                   │
                         ┌─────────▼───────────┐
                         │  MySQL (nexabot_db) │
                         └─────────────────────┘
```

---

## Slide 6: Application Workflow
```
[User Types Message]
       │
       ▼
[GUI Dispatches to Background Worker] (Multithreading)
       │
       ▼
[TextProcessor: Clean, Strip Punctuation, Lowercase, Tokenize]
       │
       ▼
[Filter Stop Words & Extract Key Terms]
       │
       ▼
[IntentDetector: Calculate Keyword & Question Similarity Confidence]
       │
       ▼
[ResponseEngine: Polymorphic Strategy Selection]
   ├── RuleBasedResponseStrategy (Greetings, Commands)
   ├── KeywordResponseStrategy (Domain Concepts)
   └── FallbackResponseStrategy (Unrecognized Queries)
       │
       ▼
[Persist Message & Intent to MySQL via MessageDAO]
       │
       ▼
[Update Thread-Safe SharedMetricsMonitor] (Synchronization)
       │
       ▼
[Render Styled Speech Bubble & Await Rating]
```

---

## Slide 7: OOP Implementation
- **Encapsulation**: All models (`User`, `Message`, `Conversation`, `Feedback`, `Intent`) use `private` member variables with validated getters and setters.
- **Inheritance**: Abstract `User` base class inherited by `RegularUser` and `Admin`, providing specialized permission logic.
- **Polymorphism**: The `ResponseStrategy` interface is dynamically implemented by `RuleBasedResponseStrategy`, `KeywordResponseStrategy`, and `FallbackResponseStrategy`.
- **Interfaces**: Formal contracts (`Repository<T, ID>`, `ResponseStrategy`, `ChatbotService`, `AuthenticationService`).
- **Custom Exceptions**: Specialized hierarchy (`DatabaseException`, `AuthenticationException`, `InvalidInputException`, `ChatbotProcessingException`) eliminating empty catch blocks.

---

## Slide 8: Collections & Generics
- **Generic Repository Interface**:
  ```java
  public interface Repository<T, ID> {
      T save(T entity) throws DatabaseException;
      Optional<T> findById(ID id) throws DatabaseException;
      List<T> findAll() throws DatabaseException;
      boolean deleteById(ID id) throws DatabaseException;
  }
  ```
- **Collections Usage**:
  - `List<Message>`: Ordered sequence of conversation exchanges.
  - `Map<String, Intent>`: Rapid O(1) keyword-to-intent lookups.
  - `Set<String>`: Stop-word filtering and unique keyword indexing.
  - `Map<String, Integer>`: Frequency tracking for analytics dashboards.

---

## Slide 9: Multithreading & Synchronization
- **ExecutorService & SwingWorker**:
  - Heavy tasks (NLP tokenization, MySQL database writes, analytics aggregation) execute asynchronously.
  - The Swing Event Dispatch Thread (EDT) never locks; UI displays a non-blocking `🤖 NexaBot is thinking...` indicator.
- **Thread Synchronization**:
  - `SharedMetricsMonitor`: Synchronized method blocks coordinate multi-thread updates to global message counters, latency averages, and intent frequency maps.
  - Eliminates race conditions and ensures thread safety.

---

## Slide 10: Database Design
- **Database:** `nexabot_db` (MySQL InnoDB)
- **Key Tables:**
  1. `users`: Credentials, salted SHA-256 password hash, role (`USER`/`ADMIN`).
  2. `conversations`: Sessions linked to `users` (`user_id` FK).
  3. `messages`: Exchange text, intent, confidence score, timestamps (`conversation_id` FK).
  4. `feedback`: Rating (1 or 0), message rating comments (`message_id` FK).
  5. `knowledge_base`: Dynamic training queries, keyword tags, answers.

---

## Slide 11: JDBC Architecture
- **Dedicated `DatabaseConnection` Singleton**: Encapsulates JDBC URL construction, connection pooling, and lifecycle.
- **PreparedStatement**: All queries use parameterized SQL statements to eliminate SQL Injection vulnerabilities.
- **Clean DAO Layer**: GUI classes never execute raw SQL; database communication is strictly channeled through DAOs (`UserDAO`, `MessageDAO`, etc.).
- **High-Resilience Fallback**: Operates in an in-memory mode if MySQL is temporarily offline, guaranteeing presentation success under any condition.

---

## Slide 12: NLP & Chatbot Processing
1. **Lowercasing & Normalization**: Standardizes character representations.
2. **Punctuation Stripping**: RegEx transforms non-alphanumeric symbols into spaces.
3. **Tokenization**: Whitespace-delimited word array generation.
4. **Stop-Word Removal**: 60+ common English filler words removed; domain keywords (OOP, JDBC, JVM) preserved.
5. **Similarity Scoring**:
   $$\text{Confidence} = (\text{Keyword Overlap Ratio} \times 0.70) + \text{Question Similarity Bonus}$$
6. **Polymorphic Dispatch**: Matches dispatched to the appropriate strategy.

---

## Slide 13: Screenshots & UI Highlights
- **Login & Registration**: Card-styled authentication with password verification and demo autofill buttons.
- **Chat Interface**: Alternating blue (User) and dark slate (Bot) speech bubbles with intent chips, confidence ratings, and timestamps.
- **Interactive Feedback**: Instant 👍 Helpful / 👎 Not Helpful buttons.
- **History Viewer**: Interactive split-pane showing past chat sessions and transcripts.
- **Analytics Dashboard**: 4 KPI cards and horizontal distribution bars.
- **Admin Portal**: Dynamic knowledge base management with search and addition forms.

---

## Slide 14: Testing & Verification
- **Automated Verification Suite (`ChatbotTestSuite.java`)**:
  - 21 automated assertions testing NLP text cleaning, password hashing, boundary validation, OOP inheritance, and response engine logic.
  - 100% test pass rate (`21 / 21 Tests Passed`).
- **Manual User Acceptance Testing**:
  - Validated edge cases: empty input strings, database connection timeouts, role privilege enforcement.

---

## Slide 15: Conclusion & Future Scope
### Conclusion
- Successfully designed and delivered **NexaBot**, a complete Java desktop AI chatbot meeting every standard of the academic project rubric.
- Exemplified authentic OOP, Collections, Generics, Concurrency, and JDBC practices.

### Future Scope
- Voice recognition and speech synthesis (STT/TTS).
- Integration with local open-source LLMs (via Ollama or ONNX Runtime).
- Multi-lingual translation capabilities.
- Cloud database synchronization.
