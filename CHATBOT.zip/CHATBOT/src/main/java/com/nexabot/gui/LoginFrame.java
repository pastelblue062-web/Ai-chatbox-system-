package com.nexabot.gui;

import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.AuthenticationException;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.User;
import com.nexabot.service.AuthenticationService;
import com.nexabot.service.AuthenticationServiceImpl;
import com.nexabot.util.UITheme;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Modern Swing Login Frame.
 * Provides user authentication, quick demo autofill, and error handling.
 */
public class LoginFrame extends JFrame {

    private final AuthenticationService authService;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel statusLabel;

    public LoginFrame() {
        this.authService = new AuthenticationServiceImpl();
        initUI();
    }

    public LoginFrame(AuthenticationService authService) {
        this.authService = authService;
        initUI();
    }

    private void initUI() {
        setTitle("NexaBot - AI Chatbot System | Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 580);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(UITheme.BG_DARK);
        mainPanel.setLayout(new BorderLayout(0, 0));
        mainPanel.setBorder(new EmptyBorder(25, 30, 25, 30));

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));

        JLabel iconLabel = new JLabel("🤖");
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel("NexaBot AI");
        titleLabel.setFont(UITheme.FONT_TITLE);
        titleLabel.setForeground(UITheme.TEXT_MAIN);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Intelligent Academic Chatbot System");
        subtitleLabel.setFont(UITheme.FONT_SMALL);
        subtitleLabel.setForeground(UITheme.TEXT_MUTED);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(iconLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        headerPanel.add(titleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 4)));
        headerPanel.add(subtitleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Card Panel with Form
        JPanel cardPanel = UITheme.createCardPanel();
        cardPanel.setLayout(new GridLayout(6, 1, 0, 10));

        JLabel emailLabel = new JLabel("Email Address");
        emailLabel.setFont(UITheme.FONT_BOLD);
        emailLabel.setForeground(UITheme.TEXT_MAIN);

        emailField = UITheme.createStyledTextField(20);
        emailField.setText("admin@nexabot.ai");

        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(UITheme.FONT_BOLD);
        passLabel.setForeground(UITheme.TEXT_MAIN);

        passwordField = UITheme.createStyledPasswordField(20);
        passwordField.setText("Admin@123");

        statusLabel = new JLabel(" ", SwingConstants.CENTER);
        statusLabel.setFont(UITheme.FONT_SMALL);
        statusLabel.setForeground(UITheme.DANGER_RED);

        JButton loginBtn = UITheme.createStyledButton("Sign In", UITheme.PRIMARY_BLUE, Color.WHITE);
        loginBtn.addActionListener(e -> performLogin());

        // Enter key shortcut
        KeyAdapter enterKeyAdapter = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performLogin();
                }
            }
        };
        emailField.addKeyListener(enterKeyAdapter);
        passwordField.addKeyListener(enterKeyAdapter);

        cardPanel.add(emailLabel);
        cardPanel.add(emailField);
        cardPanel.add(passLabel);
        cardPanel.add(passwordField);
        cardPanel.add(statusLabel);
        cardPanel.add(loginBtn);

        mainPanel.add(cardPanel, BorderLayout.CENTER);

        // Footer Panel (Registration + Quick Demo Fill)
        JPanel footerPanel = new JPanel();
        footerPanel.setOpaque(false);
        footerPanel.setLayout(new BoxLayout(footerPanel, BoxLayout.Y_AXIS));
        footerPanel.setBorder(new EmptyBorder(15, 0, 0, 0));

        JPanel registerRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
        registerRow.setOpaque(false);
        JLabel noAccountLabel = new JLabel("Don't have an account?");
        noAccountLabel.setFont(UITheme.FONT_SMALL);
        noAccountLabel.setForeground(UITheme.TEXT_MUTED);

        JButton registerBtn = new JButton("Register Here");
        registerBtn.setFont(UITheme.FONT_BOLD);
        registerBtn.setForeground(UITheme.ACCENT_CYAN);
        registerBtn.setContentAreaFilled(false);
        registerBtn.setBorderPainted(false);
        registerBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        registerBtn.addActionListener(e -> openRegisterFrame());

        registerRow.add(noAccountLabel);
        registerRow.add(registerBtn);

        // Quick autofill buttons for evaluation convenience
        JPanel quickFillRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        quickFillRow.setOpaque(false);

        JButton fillAdminBtn = new JButton("Demo Admin");
        fillAdminBtn.setFont(UITheme.FONT_SMALL);
        fillAdminBtn.setForeground(UITheme.TEXT_MUTED);
        fillAdminBtn.addActionListener(e -> {
            emailField.setText("admin@nexabot.ai");
            passwordField.setText("Admin@123");
        });

        JButton fillUserBtn = new JButton("Demo Student");
        fillUserBtn.setFont(UITheme.FONT_SMALL);
        fillUserBtn.setForeground(UITheme.TEXT_MUTED);
        fillUserBtn.addActionListener(e -> {
            emailField.setText("arifa@nexabot.ai");
            passwordField.setText("User@123");
        });

        quickFillRow.add(fillAdminBtn);
        quickFillRow.add(fillUserBtn);

        // Connection Status Banner
        String dbStatus = DatabaseConnection.getInstance().getConnectionStatusMessage();
        JLabel dbStatusLabel = new JLabel(dbStatus, SwingConstants.CENTER);
        dbStatusLabel.setFont(UITheme.FONT_SMALL);
        dbStatusLabel.setForeground(DatabaseConnection.getInstance().isConnected()
                ? UITheme.SUCCESS_GREEN : UITheme.WARNING_AMBER);
        dbStatusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        footerPanel.add(registerRow);
        footerPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        footerPanel.add(quickFillRow);
        footerPanel.add(Box.createRigidArea(new Dimension(0, 8)));
        footerPanel.add(dbStatusLabel);

        mainPanel.add(footerPanel, BorderLayout.SOUTH);

        setContentPane(mainPanel);
    }

    private void performLogin() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        statusLabel.setText("Authenticating...");
        statusLabel.setForeground(UITheme.ACCENT_CYAN);

        // Run authentication in background thread to keep UI interactive
        SwingWorker<User, Void> worker = new SwingWorker<>() {
            @Override
            protected User doInBackground() throws Exception {
                return authService.login(email, password);
            }

            @Override
            protected void done() {
                try {
                    User user = get();
                    statusLabel.setText("Login successful!");
                    statusLabel.setForeground(UITheme.SUCCESS_GREEN);

                    // Transition to ChatFrame
                    dispose();
                    SwingUtilities.invokeLater(() -> new ChatFrame(user, authService).setVisible(true));
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    statusLabel.setText(cause.getMessage());
                    statusLabel.setForeground(UITheme.DANGER_RED);
                }
            }
        };
        worker.execute();
    }

    private void openRegisterFrame() {
        dispose();
        SwingUtilities.invokeLater(() -> new RegisterFrame(authService).setVisible(true));
    }
}
