package com.nexabot.dao;

import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.Admin;
import com.nexabot.model.RegularUser;
import com.nexabot.model.User;
import com.nexabot.util.ConfigLoader;
import com.nexabot.util.PasswordUtil;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Data Access Object for User entities.
 * Demonstrates:
 *  - JDBC implementation with PreparedStatement and ResultSet
 *  - Generic Repository interface implementation
 *  - Polymorphic user mapping (Admin vs RegularUser)
 *  - Safe fallback mechanism if MySQL is offline
 */
public class UserDAO implements Repository<User, Integer> {

    private final DatabaseConnection dbManager = DatabaseConnection.getInstance();

    // In-memory fallback map for demo resilience (email -> User)
    private static final Map<String, User> fallbackUserMap = new ConcurrentHashMap<>();
    private static final AtomicInteger fallbackIdCounter = new AtomicInteger(10);

    static {
        // Initialize default demo users
        Admin defaultAdmin = new Admin(1, "System Administrator", "admin@nexabot.ai",
                PasswordUtil.hashPassword("Admin@123"), new Timestamp(System.currentTimeMillis()));
        RegularUser defaultUser1 = new RegularUser(2, "Arifa Firdous", "arifa@nexabot.ai",
                PasswordUtil.hashPassword("User@123"), new Timestamp(System.currentTimeMillis()));
        RegularUser defaultUser2 = new RegularUser(3, "Muskan Pandey", "muskan@nexabot.ai",
                PasswordUtil.hashPassword("User@123"), new Timestamp(System.currentTimeMillis()));
        RegularUser defaultUser3 = new RegularUser(4, "Rajvardhan Singh Parmar", "rajvardhan@nexabot.ai",
                PasswordUtil.hashPassword("User@123"), new Timestamp(System.currentTimeMillis()));

        fallbackUserMap.put(defaultAdmin.getEmail().toLowerCase(), defaultAdmin);
        fallbackUserMap.put(defaultUser1.getEmail().toLowerCase(), defaultUser1);
        fallbackUserMap.put(defaultUser2.getEmail().toLowerCase(), defaultUser2);
        fallbackUserMap.put(defaultUser3.getEmail().toLowerCase(), defaultUser3);
    }

    @Override
    public User save(User user) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            if (user.getUserId() == 0) {
                user.setUserId(fallbackIdCounter.incrementAndGet());
                user.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            }
            fallbackUserMap.put(user.getEmail().toLowerCase(), user);
            return user;
        }

        String sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, user.getName());
            stmt.setString(2, user.getEmail().toLowerCase());
            stmt.setString(3, user.getPassword());
            stmt.setString(4, user.getRole());

            int affectedRows = stmt.executeUpdate();
            if (affectedRows == 0) {
                throw new DatabaseException("Creating user failed, no rows affected.");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setUserId(generatedKeys.getInt(1));
                }
            }
            user.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            // Keep fallback cache in sync
            fallbackUserMap.put(user.getEmail().toLowerCase(), user);
            return user;
        } catch (SQLException e) {
            // If DB error but fallback is enabled
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                if (user.getUserId() == 0) {
                    user.setUserId(fallbackIdCounter.incrementAndGet());
                    user.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                }
                fallbackUserMap.put(user.getEmail().toLowerCase(), user);
                return user;
            }
            throw new DatabaseException("Failed to save user: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    @Override
    public Optional<User> findById(Integer userId) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackUserMap.values().stream()
                    .filter(u -> u.getUserId() == userId)
                    .findFirst();
        }

        String sql = "SELECT user_id, name, email, password, role, created_at FROM users WHERE user_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to find user by ID: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return Optional.empty();
    }

    public Optional<User> findByEmail(String email) throws DatabaseException {
        if (email == null) return Optional.empty();
        String normalizedEmail = email.trim().toLowerCase();

        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return Optional.ofNullable(fallbackUserMap.get(normalizedEmail));
        }

        String sql = "SELECT user_id, name, email, password, role, created_at FROM users WHERE email = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, normalizedEmail);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapResultSetToUser(rs));
                }
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return Optional.ofNullable(fallbackUserMap.get(normalizedEmail));
            }
            throw new DatabaseException("Failed to find user by email: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return Optional.empty();
    }

    @Override
    public List<User> findAll() throws DatabaseException {
        List<User> users = new ArrayList<>();
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            users.addAll(fallbackUserMap.values());
            return users;
        }

        String sql = "SELECT user_id, name, email, password, role, created_at FROM users ORDER BY user_id ASC";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                users.add(mapResultSetToUser(rs));
            }
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return new ArrayList<>(fallbackUserMap.values());
            }
            throw new DatabaseException("Failed to retrieve users: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
        return users;
    }

    @Override
    public boolean deleteById(Integer userId) throws DatabaseException {
        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return fallbackUserMap.values().removeIf(u -> u.getUserId() == userId);
        }

        String sql = "DELETE FROM users WHERE user_id = ?";
        try (Connection conn = dbManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            int affected = stmt.executeUpdate();
            return affected > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete user: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    /**
     * Polymorphic factory mapping a ResultSet row to either an Admin or RegularUser.
     */
    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        int id = rs.getInt("user_id");
        String name = rs.getString("name");
        String email = rs.getString("email");
        String password = rs.getString("password");
        String role = rs.getString("role");
        Timestamp createdAt = rs.getTimestamp("created_at");

        if ("ADMIN".equalsIgnoreCase(role)) {
            return new Admin(id, name, email, password, createdAt);
        } else {
            return new RegularUser(id, name, email, password, createdAt);
        }
    }
}
