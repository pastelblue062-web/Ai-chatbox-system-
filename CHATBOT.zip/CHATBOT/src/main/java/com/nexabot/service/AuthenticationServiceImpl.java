package com.nexabot.service;

import com.nexabot.dao.UserDAO;
import com.nexabot.exception.AuthenticationException;
import com.nexabot.exception.DatabaseException;
import com.nexabot.exception.InvalidInputException;
import com.nexabot.model.Admin;
import com.nexabot.model.RegularUser;
import com.nexabot.model.User;
import com.nexabot.util.PasswordUtil;
import com.nexabot.util.ValidationUtil;

import java.util.Optional;

/**
 * Service implementation for user authentication and session management.
 */
public class AuthenticationServiceImpl implements AuthenticationService {

    private final UserDAO userDAO;
    private User currentUser;

    public AuthenticationServiceImpl() {
        this.userDAO = new UserDAO();
    }

    @Override
    public User login(String email, String password) throws AuthenticationException, DatabaseException {
        if (email == null || email.trim().isEmpty()) {
            throw new AuthenticationException("Email address cannot be empty.");
        }
        if (password == null || password.isEmpty()) {
            throw new AuthenticationException("Password cannot be empty.");
        }

        Optional<User> optionalUser = userDAO.findByEmail(email.trim());
        if (optionalUser.isEmpty()) {
            throw new AuthenticationException("Invalid email or password. Please check your credentials.");
        }

        User user = optionalUser.get();
        if (!PasswordUtil.verifyPassword(password, user.getPassword())) {
            throw new AuthenticationException("Invalid email or password. Please check your credentials.");
        }

        this.currentUser = user;
        System.out.println("[AuthenticationService] User logged in: " + user.getEmail() + " (" + user.getRole() + ")");
        return user;
    }

    @Override
    public User register(String name, String email, String password, boolean isAdmin)
            throws InvalidInputException, AuthenticationException, DatabaseException {

        // 1. Validation
        ValidationUtil.validateName(name);
        ValidationUtil.validateEmail(email);
        ValidationUtil.validatePassword(password);

        // 2. Uniqueness check
        Optional<User> existing = userDAO.findByEmail(email.trim());
        if (existing.isPresent()) {
            throw new AuthenticationException("An account with this email address already exists.");
        }

        // 3. Hash password securely
        String hashedPassword = PasswordUtil.hashPassword(password);

        // 4. Polymorphic User instantiation
        User newUser;
        if (isAdmin) {
            newUser = new Admin(name.trim(), email.trim(), hashedPassword);
        } else {
            newUser = new RegularUser(name.trim(), email.trim(), hashedPassword);
        }

        User savedUser = userDAO.save(newUser);
        this.currentUser = savedUser;
        return savedUser;
    }

    @Override
    public User getCurrentUser() {
        return currentUser;
    }

    @Override
    public void logout() {
        if (currentUser != null) {
            System.out.println("[AuthenticationService] User logged out: " + currentUser.getEmail());
        }
        this.currentUser = null;
    }
}
