package com.nexabot.model;

import java.sql.Timestamp;

/**
 * Model class encapsulating user feedback (rating and comment) for a message.
 */
public class Feedback {
    private int feedbackId;
    private int messageId;
    private int userId;
    private int rating; // 1 = Helpful, 0 = Unhelpful
    private String comment;
    private Timestamp createdAt;

    public Feedback() {
    }

    public Feedback(int feedbackId, int messageId, int userId, int rating, String comment, Timestamp createdAt) {
        this.feedbackId = feedbackId;
        this.messageId = messageId;
        this.userId = userId;
        this.rating = rating;
        this.comment = comment;
        this.createdAt = createdAt;
    }

    public Feedback(int messageId, int userId, int rating, String comment) {
        this.messageId = messageId;
        this.userId = userId;
        this.rating = rating;
        this.comment = comment;
    }

    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getMessageId() {
        return messageId;
    }

    public void setMessageId(int messageId) {
        this.messageId = messageId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isHelpful() {
        return this.rating == 1;
    }

    @Override
    public String toString() {
        return "Feedback[id=" + feedbackId + ", msgId=" + messageId + ", rating=" + (rating == 1 ? "HELPFUL" : "UNHELPFUL") + "]";
    }
}
