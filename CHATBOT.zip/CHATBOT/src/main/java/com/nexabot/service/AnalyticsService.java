package com.nexabot.service;

import com.nexabot.concurrent.SharedMetricsMonitor;
import com.nexabot.dao.AnalyticsDAO;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.AnalyticsData;

import java.util.Map;

/**
 * Service providing combined database analytics and runtime thread-safe metrics.
 */
public class AnalyticsService {

    private final AnalyticsDAO analyticsDAO;
    private final SharedMetricsMonitor metricsMonitor;

    public AnalyticsService() {
        this.analyticsDAO = new AnalyticsDAO();
        this.metricsMonitor = SharedMetricsMonitor.getInstance();
    }

    /**
     * Retrieves aggregated analytics combining database records and runtime session activity.
     */
    public AnalyticsData getDashboardMetrics() throws DatabaseException {
        AnalyticsData data = analyticsDAO.getSystemAnalytics();

        // Supplement intent distribution with live session metrics
        Map<String, Integer> runtimeFrequencies = metricsMonitor.getIntentFrequencySnapshot();
        Map<String, Integer> combined = data.getIntentDistribution();

        for (Map.Entry<String, Integer> entry : runtimeFrequencies.entrySet()) {
            combined.put(entry.getKey(), combined.getOrDefault(entry.getKey(), 0) + entry.getValue());
        }

        data.setIntentDistribution(combined);
        return data;
    }

    public SharedMetricsMonitor getMetricsMonitor() {
        return metricsMonitor;
    }
}
