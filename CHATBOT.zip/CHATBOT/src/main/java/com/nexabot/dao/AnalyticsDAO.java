package com.nexabot.dao;

import com.nexabot.database.DatabaseConnection;
import com.nexabot.exception.DatabaseException;
import com.nexabot.model.AnalyticsData;
import com.nexabot.model.Feedback;
import com.nexabot.model.Message;
import com.nexabot.util.ConfigLoader;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Data Access Object specialized for aggregation queries and analytics statistics.
 * Demonstrates:
 *  - SQL Aggregations (COUNT, AVG, GROUP BY)
 *  - Java Collections (Map<String, Integer>) for frequency distributions
 */
public class AnalyticsDAO {

    private final DatabaseConnection dbManager = DatabaseConnection.getInstance();
    private final UserDAO userDAO = new UserDAO();
    private final ConversationDAO conversationDAO = new ConversationDAO();
    private final MessageDAO messageDAO = new MessageDAO();
    private final FeedbackDAO feedbackDAO = new FeedbackDAO();

    /**
     * Aggregates key system metrics.
     * Combines database SQL queries with collection-based analysis.
     */
    public AnalyticsData getSystemAnalytics() throws DatabaseException {
        AnalyticsData data = new AnalyticsData();

        if (!dbManager.isConnected() && ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
            return computeFallbackAnalytics();
        }

        try (Connection conn = dbManager.getConnection()) {
            // 1. Total Users
            try (PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM users");
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) data.setTotalUsers(rs.getInt(1));
            }

            // 2. Total Conversations
            try (PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM conversations");
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) data.setTotalConversations(rs.getInt(1));
            }

            // 3. Total Messages & Average Confidence
            try (PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*), COALESCE(AVG(confidence), 0.0) FROM messages");
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    data.setTotalMessages(rs.getInt(1));
                    data.setAverageConfidence(rs.getDouble(2));
                }
            }

            // 4. Feedback Ratings (Helpful / Unhelpful)
            try (PreparedStatement stmt = conn.prepareStatement(
                    "SELECT rating, COUNT(*) FROM feedback GROUP BY rating");
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int rating = rs.getInt(1);
                    int count = rs.getInt(2);
                    if (rating == 1) data.setHelpfulCount(count);
                    else if (rating == 0) data.setUnhelpfulCount(count);
                }
            }

            // 5. Intent Distribution & Most Common Intent
            Map<String, Integer> distribution = new HashMap<>();
            String topIntent = "N/A";
            int maxHits = -1;

            try (PreparedStatement stmt = conn.prepareStatement(
                    "SELECT intent, COUNT(*) as cnt FROM messages GROUP BY intent ORDER BY cnt DESC");
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String intent = rs.getString("intent");
                    int cnt = rs.getInt("cnt");
                    distribution.put(intent, cnt);
                    if (cnt > maxHits) {
                        maxHits = cnt;
                        topIntent = intent;
                    }
                }
            }
            data.setIntentDistribution(distribution);
            data.setMostFrequentIntent(topIntent);

            return data;
        } catch (SQLException e) {
            if (ConfigLoader.getBooleanProperty("db.demo_fallback", true)) {
                return computeFallbackAnalytics();
            }
            throw new DatabaseException("Failed to load analytics: " + e.getMessage(), e.getSQLState(), e.getErrorCode(), e);
        }
    }

    private AnalyticsData computeFallbackAnalytics() throws DatabaseException {
        AnalyticsData data = new AnalyticsData();
        data.setTotalUsers(userDAO.findAll().size());
        data.setTotalConversations(conversationDAO.findAll().size());

        List<Message> messages = messageDAO.findAll();
        data.setTotalMessages(messages.size());

        double totalConf = 0.0;
        Map<String, Integer> intentMap = new HashMap<>();
        String topIntent = "N/A";
        int maxHits = -1;

        for (Message m : messages) {
            totalConf += m.getConfidence();
            String intent = m.getIntent() != null ? m.getIntent() : "UNKNOWN";
            int count = intentMap.getOrDefault(intent, 0) + 1;
            intentMap.put(intent, count);
            if (count > maxHits) {
                maxHits = count;
                topIntent = intent;
            }
        }

        data.setAverageConfidence(messages.isEmpty() ? 0.0 : (totalConf / messages.size()));
        data.setIntentDistribution(intentMap);
        data.setMostFrequentIntent(topIntent);

        List<Feedback> feedbackList = feedbackDAO.findAll();
        int helpful = 0;
        int unhelpful = 0;
        for (Feedback f : feedbackList) {
            if (f.getRating() == 1) helpful++;
            else unhelpful++;
        }
        data.setHelpfulCount(helpful);
        data.setUnhelpfulCount(unhelpful);

        return data;
    }
}
